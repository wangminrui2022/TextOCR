//
//  WMFDrag.h
//  TextOCR
//
//  Created by 王明凡 on 13-8-28.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

#import "WMFView.h"

@interface WMFDrag : WMFView
{
    UIImageView *imageView;
}
-(id)initWithFileName:(NSString *) fileName;

@end
