//
//  WMFScaleBox.h
//  TextOCR
//
//  Created by 王明凡 on 13-8-28.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

#import "WMFView.h"
#import "WMFFrame.h"
#import "WMFDrag.h"

@interface WMFScaleBox : WMFView
{
    WMFFrame *fra;
    WMFDrag *top;
    WMFDrag *bottom;
    WMFDrag *left;
    WMFDrag *right;
    CGPoint childLocation;
    CGPoint selfLocation;
}
//获得选择的frame
-(CGRect) getSelectedFrame;

@end
