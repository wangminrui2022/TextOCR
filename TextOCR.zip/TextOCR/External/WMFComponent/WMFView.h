//
//  WMFView.h
//  TextOCR
//
//  Created by 王明凡 on 13-8-28.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

@interface WMFView : UIView
{

}
@property (nonatomic) CGFloat x;
@property (nonatomic) CGFloat y;
@property (nonatomic) CGFloat width;
@property (nonatomic) CGFloat height;

//设置当前x,y
-(void) setOrigin:(CGFloat) x y:(CGFloat) y;
//设置当前width,height
-(void) setSize:(CGFloat) width height:(CGFloat) height;

@end
