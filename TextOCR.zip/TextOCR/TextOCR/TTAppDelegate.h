//
//  TTAppDelegate.h
//  TextOCR
//
//  Created by MingFanWang on 12-10-6.
//  Copyright (c) 2012年 __MingFanWang__. All rights reserved.
//

#import "TTViewController.h"

@interface TTAppDelegate : UIResponder <UIApplicationDelegate>
{

}

@property (nonatomic,retain) UIWindow *window;
@property (nonatomic,retain) TTViewController *viewController;

@end
