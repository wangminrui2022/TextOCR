//
//  TTViewController.h
//  TextOCR
//
//  Created by 王明凡 on 12-10-6.
//  Copyright (c) 2012年 王明凡. All rights reserved.
//

@interface TTViewController : UIViewController
{
    UIImageView *background;
    UILabel *title;
}
@property (nonatomic,retain) UIButton *takePicture;
@property (nonatomic,retain) UIButton *picture;
@property (nonatomic,retain) UIButton *library;
@property (nonatomic,retain) UIButton *info;

@end
