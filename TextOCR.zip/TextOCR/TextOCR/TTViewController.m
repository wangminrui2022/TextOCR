//
//  TTViewController.m
//  TextOCR
//
//  Created by 王明凡 on 12-10-6.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "TTViewController.h"
#import "TTImage.h"

@interface TTViewController ()

@end

@implementation TTViewController

@synthesize takePicture=_takePicture;
@synthesize picture=_picture;
@synthesize library=_library;
@synthesize info=_info;

#pragma mark
#pragma mark 公共方法
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) 
    {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    _string(1,@"程序启动，参数：");
    _string(2,@"ScreenWidth",@"ScreenHeight");
    _float(2,ScreenWidth,ScreenHeight);
    _string(2,@"MainWidth",@"MainHeight");
    _float(2,MainWidth,MainHeight);
    _string(1,@"--------------");
    //背景
    UIImage *backgroundImage=[TTImage imageNamed:@"background.png"];
    background=[[UIImageView alloc] initWithImage:backgroundImage];
    [background setImage:backgroundImage];
    [self.view addSubview:background];
    //拍照
    UIImage *takePictureImage=[TTImage imageNamed:@"cameraMain.png"];
    self.takePicture=[[UIButton alloc] init];
    [self.takePicture setBackgroundImage:takePictureImage forState:UIControlStateNormal];
    [self.view addSubview:self.takePicture];
    //照片
    UIImage *pictureImage=[TTImage imageNamed:@"photoMain.png"];
    self.picture=[[UIButton alloc] init];
    [self.picture setBackgroundImage:pictureImage forState:UIControlStateNormal];
    [self.view addSubview:self.picture];
    //识别库
    UIImage *libraryImage=[TTImage imageNamed:@"folderMain.png"];
    self.library=[[UIButton alloc] init];
    [self.library setBackgroundImage:libraryImage forState:UIControlStateNormal];
    [self.view addSubview:self.library];
    //信息
    self.info=[[UIButton buttonWithType:UIButtonTypeInfoDark] autorelease];
    [self.view addSubview:self.info];
    //
    title=[[UILabel alloc] init];
    title.backgroundColor=[UIColor clearColor];
    title.textColor=[TTUtil RGBA:4.0 green:174.0 blue:218.0 alpha:1.0];
    title.font=[UIFont boldSystemFontOfSize:18.0];
    title.textAlignment=UITextAlignmentCenter;
    title.text=NSLocalizedString(@"29", nil);
    [self.view addSubview:title];
    //计算显示位置
    CGFloat selfW=MainWidth;
    CGFloat selfH=MainHeight;
    CGFloat takePictureW=takePictureImage.size.width;
    CGFloat takePictureH=takePictureImage.size.height;
    CGFloat pictureW=pictureImage.size.width;
    CGFloat pictureH=pictureImage.size.height;
    CGFloat libraryW=libraryImage.size.width;
    CGFloat libraryH=libraryImage.size.height;
    CGFloat x,y;
    //
    x=(selfW-(takePictureW+pictureW))/2;
   
    y=(selfH-(takePictureH+libraryH))/2;
     _float(4,selfH,takePictureH,libraryH,y);
    self.takePicture.frame=CGRectMake(x, y, takePictureW, takePictureH);
    //
    x=self.takePicture.frame.origin.x+self.takePicture.frame.size.width+10;
    y=self.takePicture.frame.origin.y;
    self.picture.frame=CGRectMake(x, y, pictureW, pictureH);
    //
    x=self.takePicture.frame.origin.x;
    y=self.takePicture.frame.origin.y+self.takePicture.frame.size.height+5;
    self.library.frame=CGRectMake(x, y, libraryW, libraryH);
    //
    x=(selfW-150.0)/2;
    y=self.library.frame.origin.y+self.library.frame.size.height+50;
    title.frame=CGRectMake(x,y, 150.0, 30.0);
    //
    CGFloat infoW=self.info.frame.size.width;
    CGFloat infoH=self.info.frame.size.height;
    x=title.frame.origin.x+title.frame.size.width+25;
    y=title.frame.origin.y+5;
    self.info.frame=CGRectMake(x, y, infoW, infoH);
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void) dealloc
{
    [self.takePicture release],self.takePicture=nil;
    [_takePicture release],_takePicture=nil;
    [self.picture release],self.picture=nil;
    [_picture release],_picture=nil;
    [self.library release],self.library=nil;
    [_library release],_library=nil;
    [self.info release],self.info=nil;
    [_info release],_info=nil;
    [title release],title=nil;
    [super dealloc];
}
@end
