//
//  TTCropCommand.m
//  TextOCR
//
//  Created by MingFanWang on 13-8-18.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "TTCropCommand.h"
#import "TTUIProxy.h"
#import "TTImageEditingMediator.h"
#import "TTScaleBoxMediator.h"

@implementation TTCropCommand

+(NSString *) COMMAND
{
	return @"TTCropCommand";
}

-(void) execute:(id <INotification>) note
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    CGRect selectFrame=[uiP.scaleBox getSelectedFrame];
    float _x=selectFrame.origin.x-uiP.imageEditing.editImage.frame.origin.x+uiP.imageEditing.editImage.bounds.origin.x;
    float _y=selectFrame.origin.y-uiP.imageEditing.editImage.frame.origin.y+uiP.imageEditing.editImage.bounds.origin.y;
    selectFrame=CGRectMake(_x,_y,selectFrame.size.width,selectFrame.size.height);
    //在原有的图片重绘一个指定CGRect的图片
    CGRect scaleImageFrame=[uiP.imageEditing.editImage getScaleImageFrame];
    UIImage *scaleImage=[uiP.imageEditing.editImage getScaleImage];
    UIImage *drawImage=[TTUtil drawImageWithFrame:scaleImageFrame image:scaleImage];
    uiP=nil;
    //创建一个指定区域的图片
    UIImage *image=[[UIImage alloc] initWithCGImage:CGImageCreateWithImageInRect([drawImage CGImage], selectFrame)];
    //保存到对应的沙盒目录中
    NSString *filePath =[TTUtil getPictureFilePath];
    //保存文件的名称,成功会返回YES
    NSData *data=UIImagePNGRepresentation(image);
    BOOL result=[data writeToFile:filePath atomically:YES];
    _string(2,filePath,result==YES?@"yes":@"no");
    //改变显示图片
    [self sendNotification:[TTImageEditingMediator CHANGE] body:image];
    [image release],image=nil;
}

@end
