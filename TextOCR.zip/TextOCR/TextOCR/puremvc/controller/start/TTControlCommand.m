//
//  TTControlCommand.m
//  TextOCR
//
//  Created by 王明凡 on 12-10-6.
//  Copyright (c) 2012年 王明凡. All rights reserved.
//

#import "TTControlCommand.h"
#import "TTCropCommand.h"
@implementation TTControlCommand

-(void) execute:(id <INotification>) note
{
    [self.facade registerCommand:[TTCropCommand COMMAND] commandClassRef:[TTCropCommand class]];
}

@end
