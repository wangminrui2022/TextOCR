//
//  TTModelCommand.m
//  TextOCR
//
//  Created by MingFanWang on 12-10-6.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "TTModelCommand.h"
#import "TTUIProxy.h"
#import "TTDataProxy.h"

@implementation TTModelCommand

-(void) execute:(id <INotification>) note
{	
    [self.facade registerProxy:[TTUIProxy withProxyName:[TTUIProxy NAME] data:[note body]]];
    [self.facade registerProxy:[TTDataProxy withProxyName:[TTDataProxy NAME]]];
}

@end
