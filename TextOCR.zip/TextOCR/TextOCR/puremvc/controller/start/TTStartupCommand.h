//
//  TTStartupCommand.h
//  TextOCR
//
//  Created by MingFanWang on 12-10-6.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "MacroCommand.h"

@interface TTStartupCommand : MacroCommand
{

}

//启动通知
+(NSString *) COMMAND;
//启动完成通知
+(NSString *) COMPLETE;

@end
