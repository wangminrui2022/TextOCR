//
//  TTStartupCommand.m
//  TextOCR
//
//  Created by MingFanWang on 12-10-6.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "TTStartupCommand.h"
#import "TTControlCommand.h"
#import "TTModelCommand.h"
#import "TTViewCommand.h"

@implementation TTStartupCommand

+(NSString *) COMMAND 
{
	return @"TTStartupCommand";
}

+(NSString *) COMPLETE 
{
	return @"TTStartupCommandComplete";
}

-(void)initializeMacroCommand 
{
    [self.facade removeCommand:[TTStartupCommand COMMAND]];
    /**
     * 注册顺序
     * 1.model
     * 2.control
     * 3.view
     * */
	[self addSubCommand:[TTModelCommand class]];
	[self addSubCommand:[TTControlCommand class]];
	[self addSubCommand:[TTViewCommand class]];
}

@end
