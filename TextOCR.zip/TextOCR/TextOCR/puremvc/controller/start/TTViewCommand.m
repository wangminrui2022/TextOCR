//
//  TTViewCommand.m
//  TextOCR
//
//  Created by 王明凡 on 12-10-6.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "TTViewCommand.h"
#import "TTStartupCommand.h"
#import "TTAppMediator.h"
#import "TTViewControllerMediator.h"
#import "TTCameraControlsMediator.h"
#import "TTImageEditingMediator.h"
#import "TTImageEditingControlsMediator.h"
#import "TTScaleBoxMediator.h"
#import "TTPictureLibraryMediator.h"
#import "TTTesseractEditorMediator.h"
#import "TTLanguageMediator.h"
#import "TTMBProgressHUDMediator.h"
#import "TTInfoMediator.h"
#import "TTMessageMediator.h"
#import "TTTextViewMediator.h"
#import "TTImageAlertViewMediator.h"
#import "TTCubeBottomMediator.h"
#import "TTImageEditTopMediator.h"
#import "TTSliderMediator.h"

@implementation TTViewCommand

-(void) execute:(id <INotification>) note
{
    [self.facade registerMediator:[TTAppMediator withMediatorName:[TTAppMediator NAME]]];
    [self.facade registerMediator:[TTViewControllerMediator withMediatorName:[TTViewControllerMediator NAME]]];
    [self.facade registerMediator:[TTCameraControlsMediator withMediatorName:[TTCameraControlsMediator NAME]]];
    [self.facade registerMediator:[TTImageEditingMediator withMediatorName:[TTImageEditingMediator NAME]]];
    [self.facade registerMediator:[TTImageEditingControlsMediator withMediatorName:[TTImageEditingControlsMediator NAME]]];
    [self.facade registerMediator:[TTScaleBoxMediator withMediatorName:[TTScaleBoxMediator NAME]]];
    [self.facade registerMediator:[TTPictureLibraryMediator withMediatorName:[TTPictureLibraryMediator NAME]]];
    [self.facade registerMediator:[TTTesseractEditorMediator withMediatorName:[TTTesseractEditorMediator NAME]]];
    [self.facade registerMediator:[TTLanguageMediator withMediatorName:[TTLanguageMediator NAME]]];
    [self.facade registerMediator:[TTMBProgressHUDMediator withMediatorName:[TTMBProgressHUDMediator NAME]]];
    [self.facade registerMediator:[TTInfoMediator withMediatorName:[TTInfoMediator NAME]]];
    [self.facade registerMediator:[TTMessageMediator withMediatorName:[TTMessageMediator NAME]]];
    [self.facade registerMediator:[TTTextViewMediator withMediatorName:[TTTextViewMediator NAME]]];
    [self.facade registerMediator:[TTImageAlertViewMediator withMediatorName:[TTImageAlertViewMediator NAME]]];
    [self.facade registerMediator:[TTCubeBottomMediator withMediatorName:[TTCubeBottomMediator NAME]]];
    [self.facade registerMediator:[TTImageEditTopMediator withMediatorName:[TTImageEditTopMediator NAME]]];
    [self.facade registerMediator:[TTSliderMediator withMediatorName:[TTSliderMediator NAME]]];
    //启动完成
    [self.facade sendNotification:[TTStartupCommand COMPLETE]];
}

@end
