//
//  TTAppFacade.h
//  TextOCR
//
//  Created by MingFanWang on 12-10-6.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "Facade.h"

@interface TTAppFacade : Facade
{

}

+(TTAppFacade *) getInstance;

@end
