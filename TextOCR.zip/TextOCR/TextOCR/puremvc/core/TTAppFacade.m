//
//  TTAppFacade.m
//  TextOCR
//
//  Created by MingFanWang on 12-10-6.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "TTAppFacade.h"
#import "TTStartupCommand.h"

@implementation TTAppFacade

+(TTAppFacade *) getInstance
{
    return (TTAppFacade *)[super getInstance];
}

-(void) initializeController
{
	[super initializeController];
	[self registerCommand:[TTStartupCommand COMMAND] commandClassRef:[TTStartupCommand class]];
}

@end
