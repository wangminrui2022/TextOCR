//
//  TTDataProxy.h
//  TextOCR
//
//  Created by 王明凡 on 13-1-3.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

#import "Proxy.h"

@interface TTDataProxy : Proxy
{
    
}
@property (nonatomic,retain) NSString *languageType;
//@property (nonatomic,retain) UIImage *backupImage;
@end
