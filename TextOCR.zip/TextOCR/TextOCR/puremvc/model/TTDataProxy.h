//
//  TTDataProxy.h
//  TextOCR
//
//  Created by MingFanWang on 13-1-3.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "Proxy.h"

@interface TTDataProxy : Proxy
{
    
}
@property (nonatomic,retain) NSString *languageType;
//@property (nonatomic,retain) UIImage *backupImage;
@end
