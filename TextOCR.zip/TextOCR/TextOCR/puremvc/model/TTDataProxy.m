//
//  TTDataProxy.m
//  TextOCR
//
//  Created by MingFanWang on 13-1-3.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "TTDataProxy.h"

@implementation TTDataProxy

@synthesize languageType=_languageType;
//@synthesize backupImage=_backupImage;

#pragma mark
#pragma mark 重写父类方法
+(NSString *)NAME 
{
	return @"TTDataProxy";
}

-(void)initializeProxy 
{
    [super initializeProxy];
    self.proxyName = [TTDataProxy NAME];
}


@end
