//
//  TTUIProxy.h
//  TextOCR
//
//  Created by 王明凡 on 12-10-6.
//  Copyright (c) 2012年 王明凡. All rights reserved.
//

#import "Proxy.h"
#import "TTAppDelegate.h"
#import "TTViewController.h"
#import "TTCameraControls.h"
#import "TTImageEditing.h"
#import "TTImageEditingControls.h"
#import "TTScaleBox.h"
#import "TTPictureLibrary.h"
#import "TTTesseractEditor.h"
#import "TTLanguage.h"
#import "TTInfo.h"
#import "TTMessage.h"
#import "TTTextView.h"
#import "TTSlider.h"

@interface TTUIProxy : Proxy
{

}

@property (nonatomic,retain) UIImagePickerController *picker;
@property (nonatomic,retain) TTCameraControls *cameraControls;
@property (nonatomic,retain) TTImageEditing *imageEditing;
@property (nonatomic,retain) TTImageEditingControls *imageEditingControls;
@property (nonatomic,retain) TTScaleBox *scaleBox;
@property (nonatomic,retain) TTPictureLibrary *pictureLibrary;
@property (nonatomic,retain) TTTesseractEditor *tesseractEditor;
@property (nonatomic,retain) TTLanguage *language;
@property (nonatomic,retain) TTInfo *info;
@property (nonatomic,retain) TTMessage *message;
@property (nonatomic,retain) TTTextView *textView;
@property (nonatomic,retain) TTSlider *slider;

-(TTAppDelegate *) appDelegate;
-(TTViewController *) appViewController;
-(UIView *) appView;

@end
