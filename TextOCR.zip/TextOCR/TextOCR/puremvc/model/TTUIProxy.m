//
//  TTUIProxy.m
//  TextOCR
//
//  Created by MingFanWang on 12-10-6.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "TTUIProxy.h"

@implementation TTUIProxy

@synthesize picker=_picker;
@synthesize cameraControls=_cameraControls;
@synthesize imageEditing=_imageEditing;
@synthesize imageEditingControls=_imageEditingControls;
@synthesize scaleBox=_scaleBox;
@synthesize pictureLibrary=_pictureLibrary;
@synthesize tesseractEditor=_tesseractEditor;
@synthesize language=_language;
@synthesize info=_info;
@synthesize message=_message;
@synthesize textView=_textView;
@synthesize slider=_slider;

#pragma mark
#pragma mark 重写父类方法
+(NSString *)NAME 
{
	return @"TTUIProxy";
}

-(void)initializeProxy 
{
    [super initializeProxy];
    self.proxyName = [TTUIProxy NAME];
}

#pragma mark
#pragma mark 公共方法

-(TTAppDelegate *) appDelegate;
{
    return (TTAppDelegate *)self.data;
}

-(TTViewController *) appViewController
{
    return [self appDelegate].viewController;
}

-(UIView *) appView
{
    return [self appViewController].view;
}

@end
