//
//  TTAppMediator.m
//  TextOCR
//
//  Created by 王明凡 on 12-10-6.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "TTAppMediator.h"
#import "TTStartupCommand.h"
#import "TTViewControllerMediator.h"
#import "TTDataProxy.h"

@implementation TTAppMediator

#pragma mark
#pragma mark 类方法
+(NSString *) NAME
{
    return @"AppMediator";
}

#pragma mark
#pragma mark 重写父类的方法
-(void)initializeMediator
{
    
}

-(NSArray *)listNotificationInterests
{
    return [NSArray arrayWithObjects:[TTStartupCommand COMPLETE],nil];
}

-(void)handleNotification:(id<INotification>) note
{
    if([[note name] isEqualToString:[TTStartupCommand COMPLETE]]){
        [self startComplete];
    }
}

#pragma mark
#pragma mark 私有方法
-(void) startComplete
{
   CGFloat f= round( 5.2365 * 100.0 ) / 100.0;
    _float(1,f);
    _string(1,@"pureMVC框架启动完成");
    [self sendNotification:[TTViewControllerMediator START]];
    //初始化数据
    TTDataProxy *dataP=(TTDataProxy *)[self.facade retrieveProxy:[TTDataProxy NAME]];
    //dataP.languageType=NSLocalizedString(@"12", nil);//默认英文识别
    dataP.languageType=NSLocalizedString(@"13", nil);//默认中文识别
    dataP=nil;
}

@end
