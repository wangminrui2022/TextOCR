//
//  TTCameraControlsMediator.h
//  TextOCR
//
//  Created by MingFanWang on 12-10-22.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "Mediator.h"

@interface TTCameraControlsMediator : Mediator
{
    
}

+(NSString *) NAME;
+(NSString *) SHOW;
+(NSString *) HIDE;
+(NSString *) EVENT_CLEAN;

@end
