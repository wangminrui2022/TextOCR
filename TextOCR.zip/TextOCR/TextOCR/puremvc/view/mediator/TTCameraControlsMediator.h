//
//  TTCameraControlsMediator.h
//  TextOCR
//
//  Created by 王明凡 on 12-10-22.
//  Copyright (c) 2012年 王明凡. All rights reserved.
//

#import "Mediator.h"

@interface TTCameraControlsMediator : Mediator
{
    
}

+(NSString *) NAME;
+(NSString *) SHOW;
+(NSString *) HIDE;
+(NSString *) EVENT_CLEAN;

@end
