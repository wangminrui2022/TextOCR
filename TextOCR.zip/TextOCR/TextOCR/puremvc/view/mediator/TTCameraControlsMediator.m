//
//  TTCameraControlsMediator.m
//  TextOCR
//
//  Created by MingFanWang on 12-10-22.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "TTCameraControlsMediator.h"
#import "TTUIProxy.h"
#import "TTViewControllerMediator.h"
#import "TTImageEditingControlsMediator.h"

@implementation TTCameraControlsMediator

#pragma mark
#pragma mark 类方法
+(NSString *) NAME
{
    return @"TTCameraControlsMediator";
}

+(NSString *) SHOW
{
    return @"TTCameraControlsMediatorShow";
}

+(NSString *) HIDE
{
    return @"TTCameraControlsMediatorHide";
}

+(NSString *) EVENT_CLEAN
{
    return @"TTCameraControlsMediatorEventClean";
}

#pragma mark
#pragma mark 重写父类的方法
-(void)initializeMediator
{
    
}

-(NSArray *)listNotificationInterests
{
    return [NSArray arrayWithObjects:
            [TTCameraControlsMediator SHOW],
            [TTCameraControlsMediator HIDE],
            [TTCameraControlsMediator EVENT_CLEAN],
            nil];
}

-(void)handleNotification:(id<INotification>) note
{
    if([[note name] isEqualToString:[TTCameraControlsMediator SHOW]]){
        [self show];
    }else if([[note name] isEqualToString:[TTCameraControlsMediator HIDE]]){
        [self hide];
    }else if([[note name] isEqualToString:[TTCameraControlsMediator EVENT_CLEAN]]){
        [self eventClean];
    }
}

#pragma mark
#pragma mark 私有方法

-(void) cancelClick:(id) sender
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    //当前是照片库
    if(uiP.picker.sourceType==UIImagePickerControllerSourceTypePhotoLibrary){
        //取消全屏
        if([UIApplication sharedApplication].isStatusBarHidden==YES){
            [[UIApplication sharedApplication] setStatusBarHidden:NO];
        }
    }
    //移除所有视图
    if(uiP.picker){
        [uiP.picker dismissModalViewControllerAnimated:YES];
        [uiP.picker release],uiP.picker=nil;
    }
    if(uiP.cameraControls){
        [self sendNotification:[TTCameraControlsMediator EVENT_CLEAN]];
        [uiP.cameraControls removeFromSuperview];
        [uiP.cameraControls release],uiP.cameraControls=nil;
    }
    if(uiP.imageEditingControls){
        [self sendNotification:[TTImageEditingControlsMediator EVENT_CLEAN]];
        [uiP.imageEditingControls removeFromSuperview];
        [uiP.imageEditingControls release],uiP.imageEditingControls=nil;
    }
    if(uiP.imageEditing){
        [uiP.imageEditing removeFromSuperview];
        [uiP.imageEditing release],uiP.imageEditing=nil;
    }
    if(uiP.scaleBox){
        [uiP.scaleBox removeFromSuperview];
        [uiP.scaleBox release],uiP.scaleBox=nil;
    }
    uiP=nil;
    _float(2,[TTUtil availableMemory],[TTUtil usedMemory]);
}

-(void) takePictureClick:(id) sender
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    [uiP.picker takePicture];
    uiP=nil;
}

-(void) lightClick:(id) sender
{
//    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
//    if(uiP.picker.cameraDevice==UIImagePickerControllerCameraDeviceRear){ 
//        //是否有前置摄像头
//        if([UIImagePickerController isCameraDeviceAvailable:UIImagePickerControllerCameraDeviceFront]){
//            uiP.picker.cameraDevice=UIImagePickerControllerCameraDeviceFront;
//        }
//    }else{
//        //是否有后置摄像头
//        if([UIImagePickerController isCameraDeviceAvailable:UIImagePickerControllerCameraDeviceRear]){
//            //切换按钮背景图片
//            UIImage *cutoverImageOn=[[UIImage alloc] initWithContentsOfFile:[TTUtil AbsolutePathWithFileName:@"switch_on.png"]];
//            [uiP.cameraControls.cutover setBackgroundImage:cutoverImageOn forState:UIControlStateNormal];
//            [cutoverImageOn release],cutoverImageOn=nil;
//            //
//            uiP.picker.cameraDevice=UIImagePickerControllerCameraDeviceRear;
//        }
//    }
//    uiP=nil;
}

-(void) hide
{
    [self cancelClick:nil];
}

-(void) show
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    if ([[uiP.picker.cameraOverlayView subviews] count] == 0 && uiP.cameraControls==nil){
        //底部位置
        uiP.cameraControls=[[TTCameraControls alloc] initWithContainerHeight:uiP.picker.view.frame.size.height];
        [uiP.cameraControls.cancel addTarget:self 
                                      action:@selector(cancelClick:) 
                            forControlEvents:UIControlEventTouchUpInside];
        [uiP.cameraControls.takePicture addTarget:self 
                                           action:@selector(takePictureClick:) 
                                 forControlEvents:UIControlEventTouchUpInside];
        [uiP.cameraControls.light addTarget:self
                                       action:@selector(lightClick:)
                             forControlEvents:UIControlEventTouchUpInside];
        [uiP.picker.view addSubview:uiP.cameraControls];
    }
    uiP=nil;
    _float(2,[TTUtil availableMemory],[TTUtil usedMemory]);
}


-(void) eventClean
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    [uiP.cameraControls.cancel removeTarget:self 
                                     action:@selector(cancelClick:) 
                           forControlEvents:UIControlEventTouchUpInside];
    [uiP.cameraControls.takePicture removeTarget:self 
                                          action:@selector(takePictureClick:) 
                                forControlEvents:UIControlEventTouchUpInside];
    [uiP.cameraControls.light removeTarget:self 
                                      action:@selector(lightClick:) 
                            forControlEvents:UIControlEventTouchUpInside];
    uiP=nil;
}

@end
