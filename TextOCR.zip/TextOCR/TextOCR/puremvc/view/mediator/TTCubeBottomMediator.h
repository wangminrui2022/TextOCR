//
//  TTCubeBottomMediator.h
//  TextOCR
//
//  Created by MingFanWang on 13-8-18.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "Mediator.h"

@interface TTCubeBottomMediator : Mediator
{
  
}

+(NSString *) NAME;
+(NSString *) SHOW;
+(NSString *) HIDE;
+(NSString *) CLEAN_PREVIOUS;

@end
