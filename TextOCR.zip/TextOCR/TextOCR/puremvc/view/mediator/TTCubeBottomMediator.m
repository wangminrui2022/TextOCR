//
//  TTCubeBottomMediator.m
//  TextOCR
//
//  Created by 王明凡 on 13-8-18.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

#import "TTCubeBottomMediator.h"
#import "TTUIProxy.h"
#import "TTImageEditingMediator.h"
#import "TTImageEditTopMediator.h"
#import "TTScaleBoxMediator.h"
#import "TTCropCommand.h"
#import "TTDataProxy.h"
#import "TTImageEditingMediator.h"
#import "TTSliderMediator.h"

@implementation TTCubeBottomMediator

#pragma mark
#pragma mark 类方法
+(NSString *) NAME
{
    return @"TTCubeBottomMediator";
}

+(NSString *) SHOW
{
    return @"TTCubeBottomMediatorShow";
}

+(NSString *) HIDE
{
    return @"TTCubeBottomMediatorHide";
}

+(NSString *) CLEAN_PREVIOUS
{
    return @"TTCubeBottomMediatorCleanPrevious";
}

#pragma mark
#pragma mark 重写父类的方法
-(void)initializeMediator
{
    
}

-(NSArray *)listNotificationInterests
{
    return [NSArray arrayWithObjects:
            [TTCubeBottomMediator SHOW],
            [TTCubeBottomMediator HIDE],
            [TTCubeBottomMediator CLEAN_PREVIOUS],
            nil];
}

-(void)handleNotification:(id<INotification>) note
{
    if([[note name] isEqualToString:[TTCubeBottomMediator SHOW]]){
        [self show];
    }else if([[note name] isEqualToString:[TTCubeBottomMediator HIDE]]){
        [self hide];
    }else if([[note name] isEqualToString:[TTCubeBottomMediator CLEAN_PREVIOUS]]){
        [self cleanPrevious];
    }
}

#pragma mark
#pragma mark 私有方法

-(void) show
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    [[uiP imageEditing].bottomBar.back addTarget:self
                                          action:@selector(backClick:)
                                forControlEvents:UIControlEventTouchUpInside];
    [[uiP imageEditing].bottomBar.OCR addTarget:self
                                         action:@selector(OCRClick:)
                               forControlEvents:UIControlEventTouchUpInside];
    [[uiP imageEditing].bottomBar.cancel addTarget:self
                                        action:@selector(cancelClick:)
                              forControlEvents:UIControlEventTouchUpInside];
    [[uiP imageEditing].bottomBar.done addTarget:self
                                         action:@selector(doneClick:)
                               forControlEvents:UIControlEventTouchUpInside];
}

-(void) hide
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    [[uiP imageEditing].bottomBar.back removeTarget:self
                                             action:@selector(backClick:)
                                   forControlEvents:UIControlEventTouchUpInside];
    [[uiP imageEditing].bottomBar.OCR removeTarget:self
                                            action:@selector(OCRClick:)
                                  forControlEvents:UIControlEventTouchUpInside];
    [[uiP imageEditing].bottomBar.cancel removeTarget:self
                                           action:@selector(cancelClick:)
                                 forControlEvents:UIControlEventTouchUpInside];
    [[uiP imageEditing].bottomBar.done removeTarget:self
                                            action:@selector(doneClick:)
                                  forControlEvents:UIControlEventTouchUpInside];
    
}

-(void) cleanPrevious
{
    [self sendNotification:[TTScaleBoxMediator HIDE]];
    [self sendNotification:[TTSliderMediator HIDE]];
}

/*
 返回
 */
-(void) backClick:(id) sender
{
    [self hide];
    [self sendNotification:[TTImageEditingMediator HIDE]];
    [self sendNotification:[TTImageEditTopMediator HIDE]];
    //_float(2,[TTUtil availableMemory],[TTUtil usedMemory]);
}
/*
 OCR识别
 */
-(void) OCRClick:(id) sender
{
    //    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    //    [self sendNotification:[TTTesseractEditorMediator SHOW] body:[uiP.imageEditing getScaleImage] type:@"1"];
    //    uiP=nil;
}
/*
 取消
 */
-(void) cancelClick:(id) sender
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
//    TTDataProxy *dataP=(TTDataProxy *)[self.facade retrieveProxy:[TTDataProxy NAME]];
//    //恢复原图
//    if(dataP.backupImage!=nil)
//    {
//        [self sendNotification:[TTImageEditingMediator CHANGE] body:dataP.backupImage];
//        _integer(1,[dataP.backupImage retainCount]);
//        [dataP.backupImage release],dataP.backupImage=nil;
//    }
    [self setTTCubeBottomState:TTCUBEBOTTOM_STATE1];
    if([uiP.imageEditing.topBar getSelectStatus]==TTIMAGEEDITTOP_CROP)
    {
        [self sendNotification:[TTScaleBoxMediator HIDE]];
    }
    else if([uiP.imageEditing.topBar getSelectStatus]==TTIMAGEEDITTOP_BRIGHTNESS)
    {
        [self sendNotification:[TTSliderMediator HIDE]];
    }
    else if([uiP.imageEditing.topBar getSelectStatus]==TTIMAGEEDITTOP_BLACKWHITE)
    {
        
    }else if([uiP.imageEditing.topBar getSelectStatus]==TTIMAGEEDITTOP_ROTATE_TO_LEFT)
    {
        
    }else if([uiP.imageEditing.topBar getSelectStatus]==TTIMAGEEDITTOP_ROTATE_TO_RIGHT)
    {
        
    }
}
//  //保存到用户相册(测试代码)
//  UIImage *scaleImage=[uiP.imageEditing.editImage getScaleImage];
//  UIImageWriteToSavedPhotosAlbum(scaleImage, nil, nil, nil);
/*
 完成
 */
-(void) doneClick:(id) sender
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
//    TTDataProxy *dataP=(TTDataProxy *)[self.facade retrieveProxy:[TTDataProxy NAME]];
//    //删除备份图片
//    if(dataP.backupImage!=nil)
//    {
//        _integer(1,[dataP.backupImage retainCount]);
//        [dataP.backupImage release],dataP.backupImage=nil;
//    }
    [self setTTCubeBottomState:TTCUBEBOTTOM_STATE1];
    if([uiP.imageEditing.topBar getSelectStatus]==TTIMAGEEDITTOP_CROP)
    {
        [self sendNotification:[TTCropCommand COMMAND]];
        [self sendNotification:[TTScaleBoxMediator HIDE]];
    }
    else if([uiP.imageEditing.topBar getSelectStatus]==TTIMAGEEDITTOP_BRIGHTNESS)
    {
        [self sendNotification:[TTSliderMediator HIDE]];
    }
    else if([uiP.imageEditing.topBar getSelectStatus]==TTIMAGEEDITTOP_BLACKWHITE)
    {
        
    }
    else if([uiP.imageEditing.topBar getSelectStatus]==TTIMAGEEDITTOP_ROTATE_TO_LEFT)
    {
        
    }
    else if([uiP.imageEditing.topBar getSelectStatus]==TTIMAGEEDITTOP_ROTATE_TO_RIGHT)
    {
        
    }

}

-(void) setTTCubeBottomState:(int) mode
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    if(mode==TTCUBEBOTTOM_STATE1)
    {
        [uiP.imageEditing.bottomBar setSelectStatus1];
    }
    else
    {
        [uiP.imageEditing.bottomBar setSelectStatus2];
    }
}

@end
