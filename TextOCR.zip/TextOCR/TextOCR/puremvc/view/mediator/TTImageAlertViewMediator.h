//
//  TTImageAlertViewMediator.h
//  TextOCR
//
//  Created by MingFanWang on 13-1-27.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "Mediator.h"
#import "TTImageAlertView.h"

@interface TTImageAlertViewMediator : Mediator
{
    TTImageAlertView *alert;
}

+(NSString *) NAME;
+(NSString *) SHOW;

@end
