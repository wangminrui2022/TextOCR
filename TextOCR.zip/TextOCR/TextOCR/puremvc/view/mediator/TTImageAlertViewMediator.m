//
//  TTImageAlertViewMediator.m
//  TextOCR
//
//  Created by 王明凡 on 13-1-27.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

#import "TTImageAlertViewMediator.h"

@implementation TTImageAlertViewMediator

#pragma mark
#pragma mark 类方法
+(NSString *) NAME
{
    return @"TTImageAlertViewMediator";
}

+(NSString *) SHOW
{
    return @"TTImageAlertViewMediatorShow";
}

#pragma mark
#pragma mark 重写父类的方法
-(void)initializeMediator
{
    
}

-(NSArray *)listNotificationInterests
{
    return [NSArray arrayWithObjects:
            [TTImageAlertViewMediator SHOW],
            nil];
}

-(void)handleNotification:(id<INotification>) note
{
    if([[note name] isEqualToString:[TTImageAlertViewMediator SHOW]]){
        [self show:(UIImage *)[note body]];
    }
}

#pragma mark
#pragma mark 私有方法

-(void) show:(UIImage *) image
{
    alert=[[TTImageAlertView alloc] initWithTitle:NSLocalizedString(@"24", nil)
                                          message:nil 
                                         delegate:nil 
                                cancelButtonTitle:nil 
                                otherButtonTitles:NSLocalizedString(@"7", nil), nil];
    [alert addImage:image];
    [alert show];
    [alert release],alert=nil;
}

@end
