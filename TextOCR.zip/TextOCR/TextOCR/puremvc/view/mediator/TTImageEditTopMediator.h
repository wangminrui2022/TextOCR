//
//  TTImageEditTopMediator.h
//  TextOCR
//
//  Created by 王明凡 on 13-8-18.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

#import "Mediator.h"

@interface TTImageEditTopMediator : Mediator
{
    
}

+(NSString *) NAME;
+(NSString *) SHOW;
+(NSString *) HIDE;

@end
