//
//  TTImageEditTopMediator.h
//  TextOCR
//
//  Created by MingFanWang on 13-8-18.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "Mediator.h"

@interface TTImageEditTopMediator : Mediator
{
    
}

+(NSString *) NAME;
+(NSString *) SHOW;
+(NSString *) HIDE;

@end
