//
//  TTImageEditTopMediator.m
//  TextOCR
//
//  Created by MingFanWang on 13-8-18.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "TTImageEditTopMediator.h"
#import "TTUIProxy.h"
#import "TTScaleBoxMediator.h"
#import "TTSliderMediator.h"
#import "TTDataProxy.h"
#import "TTCubeBottomMediator.h"

@implementation TTImageEditTopMediator

#pragma mark
#pragma mark 类方法
+(NSString *) NAME
{
    return @"TTImageEditTopMediator";
}

+(NSString *) SHOW
{
    return @"TTImageEditTopMediatorShow";
}

+(NSString *) HIDE
{
    return @"TTImageEditTopMediatorHide";
}


#pragma mark
#pragma mark 重写父类的方法
-(void)initializeMediator
{
    
}

-(NSArray *)listNotificationInterests
{
    return [NSArray arrayWithObjects:
            [TTImageEditTopMediator SHOW],
            [TTImageEditTopMediator HIDE],
            nil];
}

-(void)handleNotification:(id<INotification>) note
{
    if([[note name] isEqualToString:[TTImageEditTopMediator SHOW]]){
        [self show];
    }else if([[note name] isEqualToString:[TTImageEditTopMediator HIDE]]){
        [self hide];
    }
}

#pragma mark
#pragma mark 私有方法
-(void) show
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(onClick:)
                                                 name:TTIMAGEEDITTOP_CLICK
                                               object:nil];
}
-(void) hide
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void) onClick:(NSNotification*) notification
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
//    TTDataProxy *dataP=(TTDataProxy *)[self.facade retrieveProxy:[TTDataProxy NAME]];
    //清理前一步操作
    [self sendNotification:[TTCubeBottomMediator CLEAN_PREVIOUS]];
//    //备份原图，如果未备份
//    if(dataP.backupImage==nil)
//    {
//        UIImage *scaleImage=[uiP.imageEditing.editImage getScaleImage];
//        dataP.backupImage=[TTUtil copyImage:scaleImage];
//        _integer(1,[dataP.backupImage retainCount]);
//    }
    //切换底部条的状态
    if([uiP.imageEditing.bottomBar getSelectStatus]==TTCUBEBOTTOM_STATE1)
    {
        [self setTTCubeBottomState:TTCUBEBOTTOM_STATE2];
    }
    //不同编辑按钮状态
    if([uiP.imageEditing.topBar getSelectStatus]==TTIMAGEEDITTOP_CROP)//裁剪
    {
        [self sendNotification:[TTScaleBoxMediator SHOW]];
    }
    else if([uiP.imageEditing.topBar getSelectStatus]==TTIMAGEEDITTOP_BRIGHTNESS)//亮度
    {
        [self sendNotification:[TTSliderMediator SHOW]];
    }
    else if([uiP.imageEditing.topBar getSelectStatus]==TTIMAGEEDITTOP_BLACKWHITE)//黑白处理
    {
        
    }
    else if([uiP.imageEditing.topBar getSelectStatus]==TTIMAGEEDITTOP_ROTATE_TO_LEFT)//向左旋转
    {
        
    }
    else if([uiP.imageEditing.topBar getSelectStatus]==TTIMAGEEDITTOP_ROTATE_TO_RIGHT)//向右旋转
    {
        
    }
    //_float(2,[TTUtil availableMemory],[TTUtil usedMemory]);
}

-(void) setTTCubeBottomState:(int) mode
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    if(mode==TTCUBEBOTTOM_STATE1)
    {
        [uiP.imageEditing.bottomBar setSelectStatus1];
    }
    else
    {
        [uiP.imageEditing.bottomBar setSelectStatus2];
    }
}

@end
