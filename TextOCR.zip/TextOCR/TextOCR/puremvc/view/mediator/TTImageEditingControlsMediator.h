//
//  TTImageEditingControlsMediator.h
//  TextOCR
//
//  Created by MingFanWang on 12-11-4.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "Mediator.h"

enum {
    NormalStatus   = 0,
    SelectStatus   = 1,
};
typedef NSInteger TTStatus;

@interface TTImageEditingControlsMediator : Mediator
{
    NSInteger status;
}

+(NSString *) NAME;
+(NSString *) SHOW;
+(NSString *) HIDE;
+(NSString *) EVENT_CLEAN;

@end
