//
//  TTImageEditingControlsMediator.m
//  TextOCR
//
//  Created by MingFanWang on 12-11-4.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "TTImageEditingControlsMediator.h"
#import "TTUIProxy.h"
#import "TTImageEditingControls.h"
#import "TTImageEditingMediator.h"
#import "TTScaleBoxMediator.h"
#import "TTTesseractEditorMediator.h"
#import "TTPictureLibraryMediator.h"
#import "TTMessageMediator.h"
#import <AudioToolbox/AudioToolbox.h>

@implementation TTImageEditingControlsMediator

#pragma mark
#pragma mark 类方法
+(NSString *) NAME
{
    return @"TTImageEditingControlsMediator";
}

+(NSString *) SHOW
{
    return @"TTImageEditingControlsMediatorShow";
}

+(NSString *) HIDE
{
    return @"TTImageEditingControlsMediatorHide";
}

+(NSString *) EVENT_CLEAN
{
    return @"TTImageEditingControlsMediatorEventClean";
}


#pragma mark
#pragma mark 重写父类的方法
-(void)initializeMediator
{
    
}

-(NSArray *)listNotificationInterests
{
    return [NSArray arrayWithObjects:
            [TTImageEditingControlsMediator SHOW],
            [TTImageEditingControlsMediator HIDE],
            [TTImageEditingControlsMediator EVENT_CLEAN],
            nil];
}

-(void)handleNotification:(id<INotification>) note
{
    if([[note name] isEqualToString:[TTImageEditingControlsMediator SHOW]]){
        [self show];
    }else if([[note name] isEqualToString:[TTImageEditingControlsMediator HIDE]]){
        [self hide];
    }else if([[note name] isEqualToString:[TTImageEditingControlsMediator EVENT_CLEAN]]){
        [self eventClean];
    }
}

#pragma mark
#pragma mark 私有方法
//在原有的图片重绘一个指定CGRect的图片
-(UIImage *) drawWithFrame:(CGRect) frame image:(UIImage *)image 
{  
    //根据size大小创建一个基于位图的图形上下文 
    UIGraphicsBeginImageContext(frame.size);
    //获取当前Quartz 2D绘图环境
    CGContextRef context = UIGraphicsGetCurrentContext();
    //设置当前绘图环境到矩形框 
    CGContextClipToRect(context, frame);
    //绘制
    [image drawInRect:frame]; 
    //获得图片
    UIImage *drawImage = UIGraphicsGetImageFromCurrentImageContext(); 
    //从当前堆栈中删除Quartz 2D绘图环境
    UIGraphicsEndImageContext();
    return drawImage;
} 

-(void) hide
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    
    //当前是照相机还是照片库
    if(uiP.picker.sourceType==UIImagePickerControllerSourceTypeCamera){
        //底部位置
        CGFloat moveY=uiP.picker.view.frame.size.height-uiP.imageEditingControls.frame.size.height;
        //开始动画
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.3f];
        //将TTImageEditing的x移动到320.0
        uiP.imageEditingControls.frame=CGRectMake(MainWidth, moveY, uiP.imageEditingControls.frame.size.width, uiP.imageEditingControls.frame.size.height);
        //将TTCameraControls的x移动到0
        uiP.cameraControls.frame=CGRectMake(0, moveY,  uiP.cameraControls.frame.size.width,  uiP.cameraControls.frame.size.height);
        [UIView commitAnimations];
    }else {
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.3f];
        uiP.imageEditingControls.frame=CGRectMake(0, ScreenHeight, uiP.imageEditingControls.frame.size.width, uiP.imageEditingControls.frame.size.height);
        [UIView commitAnimations];
    }
    uiP=nil;
    _float(2,[TTUtil availableMemory],[TTUtil usedMemory]);
}

-(void) show
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    if(!uiP.imageEditingControls){
        uiP.imageEditingControls=[[TTImageEditingControls alloc] initWithFrame:CGRectMake(0, 0, MainWidth, 54.0)];
        [uiP.picker.view addSubview:uiP.imageEditingControls];
        [[uiP imageEditingControls].back addTarget:self 
                                             action:@selector(backClick:) 
                                   forControlEvents:UIControlEventTouchUpInside];
        [[uiP imageEditingControls].select addTarget:self 
                                              action:@selector(selectClick:) 
                                    forControlEvents:UIControlEventTouchUpInside];
        [[uiP imageEditingControls].OCR addTarget:self 
                                           action:@selector(OCRClick:) 
                                 forControlEvents:UIControlEventTouchUpInside];
    }
    //底部位置
    CGFloat moveY=uiP.picker.view.frame.size.height-uiP.imageEditingControls.frame.size.height;
    //当前是照相机还是照片库
    if(uiP.picker.sourceType==UIImagePickerControllerSourceTypeCamera){
        //将TTImageEditing的x移动到320.0
        uiP.imageEditingControls.frame=CGRectMake(MainWidth,moveY,uiP.imageEditingControls.frame.size.width,uiP.imageEditingControls.frame.size.height);
        //开始动画
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.3f];
        //将TTCameraControls的x移动到-320.0
        uiP.cameraControls.frame=CGRectMake(-MainWidth, moveY, uiP.cameraControls.frame.size.width, uiP.cameraControls.frame.size.height);
        //将TTImageEditing的x移动到0
        uiP.imageEditingControls.frame=CGRectMake(0, moveY, uiP.imageEditingControls.frame.size.width,uiP.imageEditingControls.frame.size.height);
        [UIView commitAnimations];
    }else {
        //全屏显示,状态栏隐藏
        if([UIApplication sharedApplication].isStatusBarHidden==NO){
            [[UIApplication sharedApplication] setStatusBarHidden:YES];
        }
        uiP.imageEditingControls.frame=CGRectMake(0, ScreenHeight, uiP.imageEditingControls.frame.size.width,uiP.imageEditingControls.frame.size.height);
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.3f];
        uiP.imageEditingControls.frame=CGRectMake(0, moveY, uiP.imageEditingControls.frame.size.width,uiP.imageEditingControls.frame.size.height);
        [UIView commitAnimations];
    }
    //初始化状态
    status=NormalStatus;
    uiP=nil; 
    _float(2,[TTUtil availableMemory],[TTUtil usedMemory]);
}

-(void) eventClean
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    [[uiP imageEditingControls].back removeTarget:self 
                                            action:@selector(backClick:) 
                                  forControlEvents:UIControlEventTouchUpInside];
    [[uiP imageEditingControls].select removeTarget:self 
                                             action:@selector(selectClick:) 
                                   forControlEvents:UIControlEventTouchUpInside];
    [[uiP imageEditingControls].OCR removeTarget:self
                                          action:@selector(doneClick:) 
                                forControlEvents:UIControlEventTouchUpInside];
    uiP=nil;
}

-(void) onModifyTitle
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    NSString *selectTitle;
    if(status==NormalStatus){
        selectTitle=NSLocalizedString(@"6", nil);
    }else {
        selectTitle=NSLocalizedString(@"8", nil);
    }
    [[uiP imageEditingControls].select setTitle:selectTitle forState:UIControlStateNormal];
    uiP=nil;
}

-(void) backClick:(id) sender
{
    if(status==NormalStatus){
        TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
        //当前是照片库
        if(uiP.picker.sourceType==UIImagePickerControllerSourceTypePhotoLibrary){
            //取消全屏
            if([UIApplication sharedApplication].isStatusBarHidden==YES){
                [[UIApplication sharedApplication] setStatusBarHidden:NO];
            }
        }
        uiP=nil;
        [self sendNotification:[TTImageEditingMediator HIDE]];
        [self hide];
    }else {
        status=NormalStatus;
        [self onModifyTitle];
        [self sendNotification:[TTScaleBoxMediator HIDE]];
        _float(2,[TTUtil availableMemory],[TTUtil usedMemory]);
    }
}

-(void) selectClick:(id) sender
{
    if(status==NormalStatus){
        status=SelectStatus;
        [self onModifyTitle];
        [self sendNotification:[TTImageEditingMediator SELECT]];
    }else {
        TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
        CGRect selectFrame=[uiP.scaleBox getSelectedFrame];
        selectFrame=CGRectMake(selectFrame.origin.x+uiP.imageEditing.bounds.origin.x, 
                               selectFrame.origin.y+uiP.imageEditing.bounds.origin.y, 
                               selectFrame.size.width, 
                               selectFrame.size.height);
        //在原有的图片重绘一个指定CGRect的图片
        UIImage *drawImage=[self drawWithFrame:[uiP.imageEditing getScaleImageFrame]
                                       image:[uiP.imageEditing getScaleImage]];
        uiP=nil;
        //创建一个指定区域的图片
        UIImage *image=[[UIImage alloc] initWithCGImage:CGImageCreateWithImageInRect([drawImage CGImage], selectFrame)];
        //保存到对应的沙盒目录中
        NSString *filePath =[TTUtil getPictureFilePath];
        //保存文件的名称,成功会返回YES 
        NSData *data=UIImagePNGRepresentation(image);
        BOOL result=[data writeToFile:filePath atomically:YES];
        _string(2,filePath,result==YES?@"yes":@"no");
        //改变显示图片
        [self sendNotification:[TTImageEditingMediator CHANGE] body:image];
        [image release],image=nil;
        //返回选择按钮状态
        [self backClick:nil];
        //播放系统系统声音，需要导入<AudioToolbox/AudioToolbox.h>
        AudioServicesPlaySystemSound(1007);
        //显示消息
        [self sendNotification:[TTMessageMediator SHOW] body:NSLocalizedString(@"23", nil)];
    }
}

-(void) OCRClick:(id) sender
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    [self sendNotification:[TTTesseractEditorMediator SHOW] body:[uiP.imageEditing getScaleImage] type:@"1"];
    uiP=nil;
}

@end
