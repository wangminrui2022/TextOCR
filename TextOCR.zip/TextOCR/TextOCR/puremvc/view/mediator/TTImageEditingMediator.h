//
//  TTImageEditingMediator.h
//  TextOCR
//
//  Created by MingFanWang on 12-10-28.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "Mediator.h"

@interface TTImageEditingMediator : Mediator
{
    
}

+(NSString *) NAME;
+(NSString *) SHOW;
+(NSString *) HIDE;
+(NSString *) SCROLL;
+(NSString *) CHANGE;

@end
