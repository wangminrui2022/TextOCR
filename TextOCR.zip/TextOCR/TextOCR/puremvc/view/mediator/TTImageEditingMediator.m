//
//  TTImageEditingMediator.m
//  TextOCR
//
//  Created by 王明凡 on 12-10-28.
//  Copyright (c) 2012年 王明凡. All rights reserved.
//

#import "TTImageEditingMediator.h"
#import "TTUIProxy.h"
#import "TTScaleBoxMediator.h"
#import "TTCubeBottomMediator.h"
#import "TTImageEditTopMediator.h"

@implementation TTImageEditingMediator

#pragma mark
#pragma mark 类方法
+(NSString *) NAME
{
    return @"TTImageEditingMediator";
}

+(NSString *) SHOW
{
    return @"TTImageEditingMediatorShow";
}

+(NSString *) HIDE
{
    return @"TTImageEditingMediatorHide";
}

+(NSString *) SCROLL
{
    return @"TTImageEditingMediatorScroll";
}

+(NSString *) CHANGE
{
    return @"TTImageEditingMediatorChange";
}

#pragma mark
#pragma mark 重写父类的方法
-(void)initializeMediator
{
    
}

-(NSArray *)listNotificationInterests
{
    return [NSArray arrayWithObjects:
            [TTImageEditingMediator SHOW],
            [TTImageEditingMediator HIDE],
            [TTImageEditingMediator SCROLL],
            [TTImageEditingMediator CHANGE],
            nil];
}

-(void)handleNotification:(id<INotification>) note
{
    if([[note name] isEqualToString:[TTImageEditingMediator SHOW]]){
        [self show:(UIImage *)[note body]];
    }else if([[note name] isEqualToString:[TTImageEditingMediator HIDE]]){
        [self hide];
    }else if([[note name] isEqualToString:[TTImageEditingMediator SCROLL]]){
        [self scroll];
    }else if([[note name] isEqualToString:[TTImageEditingMediator CHANGE]]){
        [self change:(UIImage *)[note body]];
    }
}

#pragma mark
#pragma mark 私有方法

-(void) show:(UIImage *) image
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    uiP.imageEditing=[[TTImageEditing alloc] initWithFrame:CGRectMake(0, 0, MainWidth, ScreenHeight) image:image];
    //当前是照片库
    if(uiP.picker.sourceType==UIImagePickerControllerSourceTypePhotoLibrary){
        //全屏显示,状态栏隐藏
        if([UIApplication sharedApplication].isStatusBarHidden==NO){
            [[UIApplication sharedApplication] setStatusBarHidden:YES];
        }
    }
    [uiP.picker.view addSubview:uiP.imageEditing];
    uiP=nil;
    [self sendNotification:[TTCubeBottomMediator SHOW]];
    [self sendNotification:[TTImageEditTopMediator SHOW]];
    //_float(2,[TTUtil availableMemory],[TTUtil usedMemory]);
}
-(void) hide
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    //当前是照片库
    if(uiP.picker.sourceType==UIImagePickerControllerSourceTypePhotoLibrary){
        //取消全屏
        if([UIApplication sharedApplication].isStatusBarHidden==YES){
            [[UIApplication sharedApplication] setStatusBarHidden:NO];
        }
    }
    [uiP.imageEditing removeFromSuperview];
    [uiP.imageEditing release];uiP.imageEditing=nil;
    uiP=nil;
    //_float(2,[TTUtil availableMemory],[TTUtil usedMemory]);
}

-(void) scroll
{
    //TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    //uiP.imageEditing.contentOffset;
    //uiP.imageEditing.contentSize;
    //[uiP.imageEditing scrollRectToVisible:CGRectMake(0, 0, 0, 0) animated:true];
    //uiP=nil;
}

-(void) change:(UIImage *) image
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    [uiP.imageEditing setScaleImage:image];
    uiP=nil;
}

@end
