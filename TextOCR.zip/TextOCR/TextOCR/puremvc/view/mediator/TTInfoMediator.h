//
//  TTInfoMediator.h
//  TextOCR
//
//  Created by 王明凡 on 13-1-20.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

#import "Mediator.h"

@interface TTInfoMediator : Mediator
<UITableViewDelegate,UITableViewDataSource>
{
    
}

+(NSString *) NAME;
+(NSString *) SHOW;
+(NSString *) HIDE;

@end
