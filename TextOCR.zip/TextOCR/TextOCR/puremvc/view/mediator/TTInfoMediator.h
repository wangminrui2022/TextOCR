//
//  TTInfoMediator.h
//  TextOCR
//
//  Created by MingFanWang on 13-1-20.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "Mediator.h"

@interface TTInfoMediator : Mediator
<UITableViewDelegate,UITableViewDataSource>
{
    
}

+(NSString *) NAME;
+(NSString *) SHOW;
+(NSString *) HIDE;

@end
