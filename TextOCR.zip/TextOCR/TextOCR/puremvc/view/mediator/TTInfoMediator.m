//
//  TTInfoMediator.m
//  TextOCR
//
//  Created by MingFanWang on 13-1-20.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "TTInfoMediator.h"
#import "TTUIProxy.h"

@implementation TTInfoMediator

#pragma mark
#pragma mark 类方法
+(NSString *) NAME
{
    return @"TTInfoMediator";
}

+(NSString *) SHOW
{
    return @"TTInfoMediatorShow";
}

+(NSString *) HIDE
{
    return @"TTInfoMediatorHide";
}


#pragma mark
#pragma mark 重写父类的方法
-(void)initializeMediator
{
    
}

-(NSArray *)listNotificationInterests
{
    return [NSArray arrayWithObjects:
            [TTInfoMediator SHOW],
            [TTInfoMediator HIDE],
            nil];
}

-(void)handleNotification:(id<INotification>) note
{
    if([[note name] isEqualToString:[TTInfoMediator SHOW]]){
        [self show];
    }else if([[note name] isEqualToString:[TTInfoMediator HIDE]]){
        [self hide];
    }
}

#pragma mark
#pragma mark 私有方法
-(void) doneClick:(id) sender
{
    [self hide];
}

- (void)animationDidStop:(NSString *)animationID
                finished:(NSNumber *)finished 
                 context:(void *)context
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    [uiP.info.done removeTarget:self
                         action:@selector(doneClick:) 
               forControlEvents:UIControlEventTouchUpInside];
    [uiP.info release],uiP.language=nil;
    uiP=nil;
    _float(2,[TTUtil availableMemory],[TTUtil usedMemory]);
}

-(void) show
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    uiP.info=[[TTInfo alloc] initWithFrame:CGRectMake(0,0,MainWidth,MainHeight)];
    uiP.info.table.dataSource=self;
    uiP.info.table.delegate=self;
    [uiP.info.done addTarget:self
                      action:@selector(doneClick:) 
            forControlEvents:UIControlEventTouchUpInside];
    [[uiP appView] addSubview:uiP.info];
    [UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.5f];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	[UIView setAnimationRepeatAutoreverses:NO];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromRight forView:uiP.appView cache:YES];//oglFlip, fromRight 	 
	[uiP.appView exchangeSubviewAtIndex:1 withSubviewAtIndex:0];
	[UIView commitAnimations];
    uiP=nil;
    _float(2,[TTUtil availableMemory],[TTUtil usedMemory]);
}
-(void) hide
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    [uiP.info removeFromSuperview];
    [UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.5f];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	[UIView setAnimationRepeatAutoreverses:NO];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:uiP.appView cache:YES];//oglFlip, fromLeft 
	[uiP.appView exchangeSubviewAtIndex:1 withSubviewAtIndex:0];
	[UIView commitAnimations];
    uiP=nil;
}

#pragma mark
#pragma mark UITableViewDelegate 
//选中一行时被调用
-(void) tableView:(UITableView *)tableView
didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *message = nil;
    NSString *title=nil;
    if([indexPath row]==0)//第一行
    {
       title=NSLocalizedString(@"19", nil);
       message=NSLocalizedString(@"21", nil);
    }
    else if([indexPath row]==1)//第二行
    {
        title=NSLocalizedString(@"20", nil);
        message=NSLocalizedString(@"22", nil);
    }
    UIAlertView *alert=[[UIAlertView alloc] initWithTitle:title
                                message:message
                               delegate:nil
                      cancelButtonTitle:nil
                      otherButtonTitles:NSLocalizedString(@"7", nil), nil];
    [alert show];
    [alert release],alert=nil;
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark 
#pragma mark UITableViewDataSource
//设置行数
-(NSInteger) tableView:(UITableView *)tableView
 numberOfRowsInSection:(NSInteger)section
{
	return 2;
}
//设置表视图单元格
-(UITableViewCell *) tableView:(UITableView *)tableView
		 cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *cellIdentifier=@"cellIdentifier";
    //由获得一个已分配的单元格
	UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
	if(cell==nil){       
        cell=[[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault 
                                     reuseIdentifier:cellIdentifier] autorelease];
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
        cell.selectionStyle=UITableViewCellSelectionStyleBlue;
    }
    NSString *title;
    if([indexPath row]==0)//第一行
    {
        title=NSLocalizedString(@"19", nil);
    }
    else if([indexPath row]==1)//第二行
    {
        title=NSLocalizedString(@"20", nil);
    }
    cell.textLabel.text=title;
	return cell;
}
@end
