//
//  TTLanguageMediator.h
//  TextOCR
//
//  Created by MingFanWang on 13-1-2.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "Mediator.h"

@interface TTLanguageMediator : Mediator
<UITableViewDelegate,UITableViewDataSource>
{
    NSArray *languageData;
    NSString *pageType;//进入页面类型(照相或拍照进入，字符库进入)
}

+(NSString *) NAME;
+(NSString *) SHOW;
+(NSString *) HIDE;

@end
