//
//  TTLanguageMediator.m
//  TextOCR
//
//  Created by 王明凡 on 13-1-2.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

#import "TTLanguageMediator.h"
#import "TTUIProxy.h"
#import "TTDataProxy.h"

@implementation TTLanguageMediator

#pragma mark
#pragma mark 类方法
+(NSString *) NAME
{
    return @"TTLanguageMediator";
}

+(NSString *) SHOW
{
    return @"TTLanguageMediatorShow";
}

+(NSString *) HIDE
{
    return @"TTLanguageMediatorHide";
}

#pragma mark
#pragma mark 重写父类的方法
-(void)initializeMediator
{
    
}

-(NSArray *)listNotificationInterests
{
    return [NSArray arrayWithObjects:
            [TTLanguageMediator SHOW],
            [TTLanguageMediator HIDE],
            nil];
}

-(void)handleNotification:(id<INotification>) note
{
    if([[note name] isEqualToString:[TTLanguageMediator SHOW]]){
        pageType=(NSString*)[note type];
        [self show];
    }else if([[note name] isEqualToString:[TTLanguageMediator HIDE]]){
        [self hide];
    }
}

#pragma mark
#pragma mark 私有方法
-(void) show
{
    //数据源
    languageData=[[NSArray alloc] initWithObjects:
                  NSLocalizedString(@"12", nil),
                  NSLocalizedString(@"13", nil),
                  nil];
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    //创建
    if([pageType isEqualToString:@"1"]){
         uiP.language=[[TTLanguage alloc] initWithFrame:CGRectMake(MainWidth,20.0,MainWidth,MainHeight)];
        [uiP.picker.view addSubview:uiP.language];
    }else{
         uiP.language=[[TTLanguage alloc] initWithFrame:CGRectMake(MainWidth,0,MainWidth,MainHeight)];
        [[uiP appView] addSubview:uiP.language];
    }
    [uiP.language.back addTarget:self action:@selector(backClick:) forControlEvents:UIControlEventTouchUpInside];
    uiP.language.table.delegate=self;
    uiP.language.table.dataSource=self;
    //开始动画
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    uiP.tesseractEditor.frame=CGRectMake(-MainWidth,uiP.tesseractEditor.frame.origin.y,uiP.tesseractEditor.frame.size.width,uiP.tesseractEditor.frame.size.height);
    uiP.language.frame=CGRectMake(0, uiP.language.frame.origin.y, uiP.language.frame.size.width,uiP.language.frame.size.height);
    [UIView commitAnimations];
    uiP=nil;
    _float(2,[TTUtil availableMemory],[TTUtil usedMemory]);
}

-(void) hide
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    //动画
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
    [UIView setAnimationDuration:0.3f];
    uiP.tesseractEditor.frame=CGRectMake(0,uiP.tesseractEditor.frame.origin.y,uiP.tesseractEditor.frame.size.width,uiP.tesseractEditor.frame.size.height);
    uiP.language.frame=CGRectMake(MainWidth, uiP.language.frame.origin.y, uiP.language.frame.size.width,uiP.language.frame.size.height);
    [UIView commitAnimations]; 
    uiP=nil;
}

- (void)animationDidStop:(NSString *)animationID
                finished:(NSNumber *)finished 
                 context:(void *)context
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    [uiP.language.back removeTarget:self 
                                action:@selector(backClick:) 
                      forControlEvents:UIControlEventTouchUpInside];
    [uiP.language removeFromSuperview];
    [uiP.language release],uiP.language=nil;
    [languageData release],languageData=nil;
    uiP=nil;
    _float(2,[TTUtil availableMemory],[TTUtil usedMemory]);
}

-(void) backClick:(id) sender
{
    [self hide];
}

#pragma mark
#pragma mark UITableViewDelegate 
//选中一行时被调用
-(void) tableView:(UITableView *)tableView
didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //设置当前选中
    UITableViewCell *cell=[tableView cellForRowAtIndexPath:indexPath];
    cell.accessoryType=UITableViewCellAccessoryCheckmark;
    TTDataProxy *dataP=(TTDataProxy *)[self.facade retrieveProxy:[TTDataProxy NAME]];
    dataP.languageType=cell.textLabel.text;
    dataP=nil;
    //设置其他未选中
    NSArray *cells=[tableView visibleCells];
    for(int i=0;i<cells.count;i++){
        UITableViewCell *temp=(UITableViewCell *)[cells objectAtIndex:i];
        if(temp!=cell){
            temp.accessoryType=UITableViewCellAccessoryNone;
        }
    }
    //表格选中效果动画隐藏
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
}
//指定行高
- (CGFloat)tableView:(UITableView *)tableView 
heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50.0;
}

#pragma mark 
#pragma mark UITableViewDataSource
//设置行数
-(NSInteger) tableView:(UITableView *)tableView
 numberOfRowsInSection:(NSInteger)section
{
	return languageData.count;
}
//设置表视图单元格
-(UITableViewCell *) tableView:(UITableView *)tableView
		 cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *cellIdentifier=@"cellIdentifier";
    //由获得一个已分配的单元格
	UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
	if(cell==nil){       
        cell=[[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault 
                                     reuseIdentifier:cellIdentifier] autorelease];
	}
    cell.textLabel.text=[languageData objectAtIndex:indexPath.row];
    //设置默认语言选中
    TTDataProxy *dataP=(TTDataProxy *)[self.facade retrieveProxy:[TTDataProxy NAME]];
    if([dataP.languageType isEqualToString:cell.textLabel.text]){
        cell.accessoryType=UITableViewCellAccessoryCheckmark;
    }
    dataP=nil;
	return cell;
}

@end
