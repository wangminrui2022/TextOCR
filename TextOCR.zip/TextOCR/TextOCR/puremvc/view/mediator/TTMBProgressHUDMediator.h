//
//  TTMBProgressHUDMediator.h
//  TextOCR
//
//  Created by 王明凡 on 13-1-27.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

#import "Mediator.h"
#import "MBProgressHUD.h"

@interface TTMBProgressHUDMediator : Mediator
{
    MBProgressHUD *progress;
}

+(NSString *) NAME;
+(NSString *) SHOW;
+(NSString *) HIDE;

@end
