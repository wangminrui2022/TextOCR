//
//  TTMBProgressHUDMediator.h
//  TextOCR
//
//  Created by MingFanWang on 13-1-27.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "Mediator.h"
#import "MBProgressHUD.h"

@interface TTMBProgressHUDMediator : Mediator
{
    MBProgressHUD *progress;
}

+(NSString *) NAME;
+(NSString *) SHOW;
+(NSString *) HIDE;

@end
