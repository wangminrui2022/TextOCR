//
//  TTMBProgressHUDMediator.m
//  TextOCR
//
//  Created by MingFanWang on 13-1-27.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "TTMBProgressHUDMediator.h"
#import "TTUIProxy.h"

@implementation TTMBProgressHUDMediator

#pragma mark
#pragma mark 类方法
+(NSString *) NAME
{
    return @"TTMBProgressHUDMediator";
}

+(NSString *) SHOW
{
    return @"TTMBProgressHUDMediatorShow";
}

+(NSString *) HIDE
{
    return @"TTMBProgressHUDMediatorHide";
}

#pragma mark
#pragma mark 重写父类的方法
-(void)initializeMediator
{
    
}

-(NSArray *)listNotificationInterests
{
    return [NSArray arrayWithObjects:
            [TTMBProgressHUDMediator SHOW],
            [TTMBProgressHUDMediator HIDE],
            nil];
}

-(void)handleNotification:(id<INotification>) note
{
    if([[note name] isEqualToString:[TTMBProgressHUDMediator SHOW]]){
        [self show];
    }else if([[note name] isEqualToString:[TTMBProgressHUDMediator HIDE]]){
        [self hide];
    }
}

#pragma mark
#pragma mark 私有方法
-(void) show
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    if(uiP.tesseractEditor){//如果是tesseractEditor打开
        progress=[[MBProgressHUD alloc] initWithView:[uiP.tesseractEditor superview]];
        [[uiP.tesseractEditor superview] addSubview:progress];
    }else{
        progress=[[MBProgressHUD alloc] initWithView:[uiP appView]];
        [[uiP appView] addSubview:progress];
    }
    progress.labelText=NSLocalizedString(@"15", nil);
    progress.dimBackground=YES;
    [progress show:YES];
    uiP=nil;
}
-(void) hide
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    [progress hide:YES];
    [progress removeFromSuperview];
    [progress release],progress=nil;
    uiP=nil;
}

@end
