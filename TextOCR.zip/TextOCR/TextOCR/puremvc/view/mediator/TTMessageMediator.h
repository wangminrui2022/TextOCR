//
//  TTMessageMediator.h
//  TextOCR
//
//  Created by MingFanWang on 13-1-22.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "Mediator.h"

@interface TTMessageMediator : Mediator
{
    
}

+(NSString *) NAME;
+(NSString *) SHOW;
+(NSString *) HIDE;

@end
