//
//  TTMessageMediator.m
//  TextOCR
//
//  Created by 王明凡 on 13-1-22.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

#import "TTMessageMediator.h"
#import "TTUIProxy.h"
#import "TTMessage.h"

@implementation TTMessageMediator

#pragma mark
#pragma mark 类方法
+(NSString *) NAME
{
    return @"TTMessageMediator";
}

+(NSString *) SHOW
{
    return @"TTMessageMediatorShow";
}

+(NSString *) HIDE
{
    return @"TTMessageMediatorHide";
}

#pragma mark
#pragma mark 重写父类的方法
-(void)initializeMediator
{
    
}

-(NSArray *)listNotificationInterests
{
    return [NSArray arrayWithObjects:
            [TTMessageMediator SHOW],
            [TTMessageMediator HIDE],
            nil];
}

-(void)handleNotification:(id<INotification>) note
{
    if([[note name] isEqualToString:[TTMessageMediator SHOW]]){
        [self show:(NSString *)[note body]];
    }else if([[note name] isEqualToString:[TTMessageMediator HIDE]]){
        [self hide];
    }
}


#pragma mark
#pragma mark 私有方法

-(void) show:(NSString *) text
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    if(uiP.message!=nil){
        [uiP.message removeFromSuperview];
        [uiP.message release],uiP.message=nil; 
    }
    uiP.message=[[TTMessage alloc] initWithFrame:CGRectMake(0, -40.0, MainWidth, 40.0) text:text];
    [uiP.picker.view addSubview:uiP.message];
    [UIView beginAnimations:[TTMessageMediator SHOW] context:nil];
	[UIView setAnimationDuration:0.3f];	
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
    uiP.message.frame=CGRectMake(0, 0, uiP.message.frame.size.width, uiP.message.frame.size.height);
	[UIView commitAnimations];
    uiP=nil;
    _float(2,[TTUtil availableMemory],[TTUtil usedMemory]);
}

-(void) hide
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    [UIView beginAnimations:[TTMessageMediator HIDE] context:nil];
	[UIView setAnimationDuration:0.3f];	
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
    uiP.message.frame=CGRectMake(0, -40.0, uiP.message.frame.size.width, uiP.message.frame.size.height);
	[UIView commitAnimations];
    uiP=nil;
}

-(void) hideProcessing:(id) sender
{
    [NSThread sleepForTimeInterval:0.5f];
    [self hide];
}

- (void)animationDidStop:(NSString *)animationID
                finished:(NSNumber *)finished 
                 context:(void *)context
{
    if([animationID isEqualToString:[TTMessageMediator SHOW]]){
        [NSThread detachNewThreadSelector:@selector(hideProcessing:) toTarget:self withObject:nil];
    }else {
        TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
        [uiP.message removeFromSuperview];
        [uiP.message release],uiP.message=nil;
        uiP=nil; 
    }
    _float(2,[TTUtil availableMemory],[TTUtil usedMemory]);
}

@end
