//
//  TTPictureLibraryMediator.h
//  TextOCR
//
//  Created by 王明凡 on 12-12-18.
//  Copyright (c) 2012年 王明凡. All rights reserved.
//

#import "Mediator.h"

@interface TTPictureLibraryMediator : Mediator
<UITableViewDelegate,UITableViewDataSource>
{
    NSMutableArray *files;
}

+(NSString *) NAME;
+(NSString *) SHOW;
+(NSString *) HIDE;

@end
