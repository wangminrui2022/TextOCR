//
//  TTPictureLibraryMediator.m
//  TextOCR
//
//  Created by 王明凡 on 12-12-18.
//  Copyright (c) 2012年 王明凡. All rights reserved.
//

#import "TTPictureLibraryMediator.h"
#import "TTUIProxy.h"
#import "TTTesseractEditorMediator.h"

@implementation TTPictureLibraryMediator

#pragma mark
#pragma mark 类方法
+(NSString *) NAME
{
    return @"TTPictureLibraryMediator";
}

+(NSString *) SHOW
{
    return @"TTPictureLibraryMediatorShow";
}

+(NSString *) HIDE
{
    return @"TTPictureLibraryMediatorHide";
}

#pragma mark
#pragma mark 重写父类的方法
-(void)initializeMediator
{
    
}

-(NSArray *)listNotificationInterests
{
    return [NSArray arrayWithObjects:
            [TTPictureLibraryMediator SHOW],
            [TTPictureLibraryMediator HIDE],
            nil];
}

-(void)handleNotification:(id<INotification>) note
{
    if([[note name] isEqualToString:[TTPictureLibraryMediator SHOW]]){
        [self show];
    }
    else if([[note name] isEqualToString:[TTPictureLibraryMediator HIDE]]){
        [self hide];
    }
}

#pragma mark
#pragma mark 私有方法
-(void) show
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    //创建
    uiP.pictureLibrary=[[TTPictureLibrary alloc] initWithFrame:CGRectMake(0,ScreenHeight,MainWidth,MainHeight)];
    [uiP.pictureLibrary.back addTarget:self 
                                action:@selector(backClick:) 
                      forControlEvents:UIControlEventTouchUpInside];
    [uiP.pictureLibrary.deleted addTarget:self 
                                   action:@selector(deletedClick:) 
                         forControlEvents:UIControlEventTouchUpInside];
    uiP.pictureLibrary.table.delegate=self;
    uiP.pictureLibrary.table.dataSource=self;
    [[uiP appView] addSubview:uiP.pictureLibrary];
    //动画
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3f];
    uiP.pictureLibrary.frame=CGRectMake(0,0, uiP.pictureLibrary.frame.size.width,uiP.pictureLibrary.frame.size.height);
    [UIView commitAnimations]; 
    uiP=nil;
    //获取图片路径集合
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *er=nil;
    NSString *picture=[TTUtil AbsolutePathWithFileName:@"picture"];
    NSArray * paths=[fileManager contentsOfDirectoryAtPath:picture error:&er];
    //如果错误指针不为空
    if(er!=nil){
        NSLog(@"错误信息描述:%@",[er localizedDescription]);
        NSLog(@"错误信息解释:%@",[er localizedFailureReason]);
    }else {
        //文件数量大于1
        if(paths.count>0){
            NSMutableArray *temp=[[NSMutableArray alloc] init];
            for(NSString *image in paths){
                image=[picture stringByAppendingFormat:@"%@%@",@"/",image];
                [temp addObject:image];
            }
            //数组进行排序并
            NSArray *sort=[temp sortedArrayUsingComparator: ^(id obj1, id obj2)
                           {
                               NSString *string1 = (NSString *)obj1;
                               NSString *string2 = (NSString *)obj2;
                               return [string2 compare:string1];
                           }];
            //转换NSArray到NSMutableArray
            files=[[NSMutableArray alloc] initWithArray:sort];
            [temp release],temp=nil;
        }else {
            files=[[NSMutableArray alloc] init];
        }
    }
    _float(2,[TTUtil availableMemory],[TTUtil usedMemory]);
}
-(void) hide
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    //动画
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
    [UIView setAnimationDuration:0.3f];
    uiP.pictureLibrary.frame=CGRectMake(0,ScreenHeight, uiP.pictureLibrary.frame.size.width, uiP.pictureLibrary.frame.size.height);
    [UIView commitAnimations]; 
    uiP=nil;
}

-(void) backClick:(id) sender
{
    [self hide];
}

-(void) deletedClick:(id) sender
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
	[uiP.pictureLibrary.table setEditing:!uiP.pictureLibrary.table.editing animated:YES];
    if (uiP.pictureLibrary.table.editing){
        [uiP.pictureLibrary.deleted setTitle:NSLocalizedString(@"4", nil) forState:UIControlStateNormal];
    }else{
        [uiP.pictureLibrary.deleted setTitle:NSLocalizedString(@"28", nil) forState:UIControlStateNormal];
    }
}

- (void)animationDidStop:(NSString *)animationID
                finished:(NSNumber *)finished 
                 context:(void *)context
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    [uiP.pictureLibrary.back removeTarget:self action:@selector(backClick:) forControlEvents:UIControlEventTouchUpInside];
    [uiP.pictureLibrary removeFromSuperview];
    [uiP.pictureLibrary release],uiP.pictureLibrary=nil;
    [files release],files=nil;
    uiP=nil;
    _float(2,[TTUtil availableMemory],[TTUtil usedMemory]);
}

#pragma mark
#pragma mark UITableViewDelegate 
//选中一行时被调用
-(void) tableView:(UITableView *)tableView
didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *file=[files objectAtIndex:indexPath.row];
    UIImage *image=[[UIImage alloc] initWithContentsOfFile:file];
    [self sendNotification:[TTTesseractEditorMediator SHOW] body:image type:@"2"];
    [image release],image=nil;
    //表格选中效果动画隐藏
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
}
//指定行高
- (CGFloat)tableView:(UITableView *)tableView 
heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 120.0;
}
//编辑行
-(void) tableView:(UITableView *)tableView
commitEditingStyle:(UITableViewCellEditingStyle)editingStyle
forRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSUInteger row=[indexPath row];
	//删除文件
    NSString *file=[files objectAtIndex:indexPath.row];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if([fileManager fileExistsAtPath:file]){
         NSError *er=nil;
        if([fileManager removeItemAtPath:file error:&er]==NO){
            if(er!=nil){
                NSLog(@"错误信息描述:%@",[er localizedDescription]);
                NSLog(@"错误信息解释:%@",[er localizedFailureReason]);
            }   
        }
    }
    //从数组中删除
	[files removeObjectAtIndex:row];
	[tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] 
					 withRowAnimation:UITableViewRowAnimationFade];
}
#pragma mark 
#pragma mark UITableViewDataSource
//设置行数
-(NSInteger) tableView:(UITableView *)tableView
 numberOfRowsInSection:(NSInteger)section
{
	return files.count;
}
//设置表视图单元格
-(UITableViewCell *) tableView:(UITableView *)tableView
		 cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *cellIdentifier=@"cellIdentifier";
    //由获得一个已分配的单元格
	UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    UIImageView *imageView;
	if(cell==nil){       
        cell=[[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault 
                                     reuseIdentifier:cellIdentifier] autorelease];
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
        //创建图片
        //imageView=[[UIImageView alloc] initWithFrame:CGRectMake(5.0, 5.0, 110.0, 110.0)];
        imageView=[[UIImageView alloc] init];
        [cell.contentView addSubview:imageView];
        [imageView release],imageView=nil;
	}
    //获取标题和内容组件
    for (UIView *view in cell.contentView.subviews){
        if ([view isMemberOfClass:[UIImageView class]]){
            imageView = (UIImageView *)view;
        } 
    }
    //设置图片
    NSString *file=[files objectAtIndex:indexPath.row];
    UIImage *image=[[UIImage alloc] initWithContentsOfFile:file];
    imageView.frame=[TTUtil scaleFrameWithContainer:CGSizeMake(120.0, 120.0) child:image.size];
    [imageView setImage:image];
    [image release],image=nil;
	return cell;
}

@end
