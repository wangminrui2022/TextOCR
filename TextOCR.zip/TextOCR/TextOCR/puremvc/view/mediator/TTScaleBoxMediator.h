//
//  TTScaleBoxMediator.h
//  TextOCR
//
//  Created by 王明凡 on 12-12-16.
//  Copyright (c) 2012年 王明凡. All rights reserved.
//

#import "Mediator.h"
#import "TTScaleBox.h"

@interface TTScaleBoxMediator : Mediator
{
    
}

+(NSString *) NAME;
+(NSString *) SHOW;
+(NSString *) HIDE;

@end
