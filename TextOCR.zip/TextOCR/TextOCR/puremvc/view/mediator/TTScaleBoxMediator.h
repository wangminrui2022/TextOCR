//
//  TTScaleBoxMediator.h
//  TextOCR
//
//  Created by MingFanWang on 12-12-16.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "Mediator.h"
#import "TTScaleBox.h"

@interface TTScaleBoxMediator : Mediator
{
    
}

+(NSString *) NAME;
+(NSString *) SHOW;
+(NSString *) HIDE;

@end
