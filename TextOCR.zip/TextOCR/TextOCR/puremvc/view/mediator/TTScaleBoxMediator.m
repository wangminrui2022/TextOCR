//
//  TTScaleBoxMediator.m
//  TextOCR
//
//  Created by 王明凡 on 12-12-16.
//  Copyright (c) 2012年 王明凡. All rights reserved.
//

#import "TTScaleBoxMediator.h"
#import "TTUIProxy.h"

@implementation TTScaleBoxMediator

#pragma mark
#pragma mark 类方法
+(NSString *) NAME
{
    return @"TTScaleBoxMediator";
}

+(NSString *) SHOW
{
    return @"TTScaleBoxMediatorShow";
}

+(NSString *) HIDE
{
    return @"TTScaleBoxMediatorHide";
}


#pragma mark
#pragma mark 重写父类的方法
-(void)initializeMediator
{
    
}

-(NSArray *)listNotificationInterests
{
    return [NSArray arrayWithObjects:
            [TTScaleBoxMediator SHOW],
            [TTScaleBoxMediator HIDE],
            nil];
}

-(void)handleNotification:(id<INotification>) note
{
    if([[note name] isEqualToString:[TTScaleBoxMediator SHOW]]){
        [self show];
    }
    else if([[note name] isEqualToString:[TTScaleBoxMediator HIDE]]){
        [self hide];
    }
}

#pragma mark
#pragma mark 私有方法
-(void) show
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    if(uiP.scaleBox==nil)
    {
        uiP.scaleBox=[[TTScaleBox alloc] initWithFrame:uiP.imageEditing.frame];
        [uiP.imageEditing insertSubview:uiP.scaleBox aboveSubview:uiP.imageEditing.editImage];
    }
    uiP=nil;
}

-(void) hide
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    if(uiP.scaleBox!=nil)
    {
        [uiP.scaleBox removeFromSuperview];
        [uiP.scaleBox release],uiP.scaleBox=nil;
    }
    uiP=nil;
}

@end
