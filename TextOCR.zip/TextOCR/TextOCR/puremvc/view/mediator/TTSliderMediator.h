//
//  TTSliderMediator.h
//  TextOCR
//
//  Created by MingFanWang on 13-8-29.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "Mediator.h"

@interface TTSliderMediator : Mediator
{
    
}

+(NSString *) NAME;
+(NSString *) SHOW;
+(NSString *) HIDE;

@end
