//
//  TTSliderMediator.m
//  TextOCR
//
//  Created by 王明凡 on 13-8-29.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

#import "TTSliderMediator.h"
#import "TTUIProxy.h"
#import "TTFilter.h"
#import "TTImageEditingMediator.h"
#import "TTDataProxy.h"
#import "TTCubeBottomMediator.h"

@implementation TTSliderMediator

#pragma mark
#pragma mark 类方法
+(NSString *) NAME
{
    return @"TTSliderMediator";
}

+(NSString *) SHOW
{
    return @"TTSliderMediatorShow";
}

+(NSString *) HIDE
{
    return @"TTSliderMediatorHide";
}


#pragma mark
#pragma mark 重写父类的方法
-(void)initializeMediator
{
    
}

-(NSArray *)listNotificationInterests
{
    return [NSArray arrayWithObjects:
            [TTSliderMediator SHOW],
            [TTSliderMediator HIDE],
            nil];
}

-(void)handleNotification:(id<INotification>) note
{
    if([[note name] isEqualToString:[TTSliderMediator SHOW]]){
        [self show];
    }else if([[note name] isEqualToString:[TTSliderMediator HIDE]]){
        [self hide];
    }
}

#pragma mark
#pragma mark 私有方法
-(void) show
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    if(uiP.slider==nil){
        CGFloat _w=190.0;
        CGFloat _h=40.0;
        CGFloat _x=(MainWidth-_w)/2;
        CGFloat _y=MainHeight-[uiP imageEditing].bottomBar.frame.size.height-_h;
        uiP.slider=[[TTSlider alloc] initWithFrame:CGRectMake(_x, _y, _w, _h)];
        [uiP.imageEditing insertSubview:uiP.slider aboveSubview:uiP.imageEditing.editImage];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(onSliderTouchUpInside:)
                                                     name:TTSLIDER_TOUCHUPINSIDE
                                                   object:nil];
    }
    uiP=nil;
}

-(void) hide
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    if(uiP.slider!=nil){
        [[NSNotificationCenter defaultCenter] removeObserver:self];
        [uiP.slider removeFromSuperview];
        [uiP.slider release],uiP.slider=nil;
    }
    uiP=nil;
}

-(void) onSliderTouchUpInside:(NSNotification*) notification
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    double value=[uiP.slider getSliderValue];
    TTFilter *filter=[[TTFilter alloc] init];
    TTDataProxy *dataP=(TTDataProxy *)[self.facade retrieveProxy:[TTDataProxy NAME]];
    //UIImage *scaleImage=dataP.backupImage;
     UIImage *scaleImage=[uiP.imageEditing.editImage getScaleImage];
    
    //UIImage *img=[[UIImage alloc] initWithCGImage:[scaleImage CGImage]];
//    _integer(1,[dataP.backupImage retainCount]);
    UIImage *newImage=[filter filterBrightnessWithImage:[scaleImage CGImage] context:&value];
    [self sendNotification:[TTImageEditingMediator CHANGE] body:newImage];
    [filter release],filter=nil;
}

@end
