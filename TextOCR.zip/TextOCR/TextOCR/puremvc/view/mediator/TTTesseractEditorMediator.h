//
//  TTTesseractEditorMediator.h
//  TextOCR
//
//  Created by 王明凡 on 12-12-19.
//  Copyright (c) 2012年 王明凡. All rights reserved.
//

#import "Mediator.h"

@interface TTTesseractEditorMediator : Mediator
{
    NSString *pageType;//进入页面类型(照相或拍照进入，字符库进入)
}

+(NSString *) NAME;
+(NSString *) SHOW;
+(NSString *) HIDE;

@end
