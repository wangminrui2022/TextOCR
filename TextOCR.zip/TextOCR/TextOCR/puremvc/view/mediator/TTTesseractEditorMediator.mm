//
//  TTTesseractEditorMediator.m
//  TextOCR
//
//  Created by MingFanWang on 12-12-19.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "TTTesseractEditorMediator.h"
#import "TTUIProxy.h"
#import "TTLanguageMediator.h"
#import "TTTesseract.h"
#import "TTDataProxy.h"
#import "TTTextViewMediator.h"
#import "TTMBProgressHUDMediator.h"

@implementation TTTesseractEditorMediator

#pragma mark
#pragma mark 类方法
+(NSString *) NAME
{
    return @"TTTesseractEditorMediator";
}

+(NSString *) SHOW
{
    return @"TTTesseractEditorMediatorShow";
}

+(NSString *) HIDE
{
    return @"TTTesseractEditorMediatorHide";
}


#pragma mark
#pragma mark 重写父类的方法
-(void)initializeMediator
{
    
}

-(NSArray *)listNotificationInterests
{
    return [NSArray arrayWithObjects:
            [TTTesseractEditorMediator SHOW],
            [TTTesseractEditorMediator HIDE],
            nil];
}

-(void)handleNotification:(id<INotification>) note
{
    if([[note name] isEqualToString:[TTTesseractEditorMediator SHOW]]){
        pageType=(NSString*)[note type];
        [self show:(UIImage *)[note body]];
    }else if([[note name] isEqualToString:[TTTesseractEditorMediator HIDE]]){
        [self hide];
    }
}

#pragma mark
#pragma mark 私有方法
-(void) show:(UIImage *) image
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    //创建
    if([pageType isEqualToString:@"1"]){//照相机或照片库进入图片识别
        //取消全屏
        if([UIApplication sharedApplication].isStatusBarHidden==YES){
            [[UIApplication sharedApplication] setStatusBarHidden:NO];
        }
        uiP.tesseractEditor=[[TTTesseractEditor alloc] initWithFrame:CGRectMake(MainWidth,20.0,MainWidth,MainHeight) image:image];
        [uiP.picker.view addSubview:uiP.tesseractEditor];
    }else{//图片库进入识别
        uiP.tesseractEditor=[[TTTesseractEditor alloc] initWithFrame:CGRectMake(MainWidth,0,MainWidth,MainHeight) image:image];
        [[uiP appView] addSubview:uiP.tesseractEditor];
    }
    [uiP.tesseractEditor.back addTarget:self action:@selector(backClick:) forControlEvents:UIControlEventTouchUpInside];
    [uiP.tesseractEditor.OCR addTarget:self action:@selector(OCRClick:) forControlEvents:UIControlEventTouchUpInside];
    [uiP.tesseractEditor.language addTarget:self action:@selector(languageClick:) forControlEvents:UIControlEventTouchUpInside];
    //开始动画
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    if([pageType isEqualToString:@"1"]){
        CGFloat moveY=uiP.picker.view.frame.size.height-uiP.imageEditingControls.frame.size.height;
        uiP.imageEditing.frame=CGRectMake(-MainWidth, 0, uiP.imageEditing.frame.size.width, uiP.imageEditing.frame.size.height);
        uiP.imageEditingControls.frame=CGRectMake(-MainWidth, moveY, uiP.imageEditingControls.frame.size.width,uiP.imageEditingControls.frame.size.height);
    }else{
        uiP.pictureLibrary.frame=CGRectMake(-MainWidth,0,uiP.pictureLibrary.frame.size.width,uiP.pictureLibrary.frame.size.height);
    }
    uiP.tesseractEditor.frame=CGRectMake(0,uiP.tesseractEditor.frame.origin.y,uiP.tesseractEditor.frame.size.width,uiP.tesseractEditor.frame.size.height);
    [UIView commitAnimations];
    uiP=nil;
    _float(2,[TTUtil availableMemory],[TTUtil usedMemory]);
}

-(void) hide
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    //动画
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
    [UIView setAnimationDuration:0.3f];
    if([pageType isEqualToString:@"1"]){
        //全屏显示,状态栏隐藏
        if([UIApplication sharedApplication].isStatusBarHidden==NO){
            [[UIApplication sharedApplication] setStatusBarHidden:YES];
        }
        CGFloat moveY=uiP.picker.view.frame.size.height-uiP.imageEditingControls.frame.size.height;
        uiP.imageEditing.frame=CGRectMake(0, 0, uiP.imageEditing.frame.size.width, uiP.imageEditing.frame.size.height);
        uiP.imageEditingControls.frame=CGRectMake(0, moveY, uiP.imageEditingControls.frame.size.width,uiP.imageEditingControls.frame.size.height);
    }else{
        uiP.pictureLibrary.frame=CGRectMake(0,0,uiP.pictureLibrary.frame.size.width,uiP.pictureLibrary.frame.size.height);
    }
    uiP.tesseractEditor.frame=CGRectMake(MainWidth,0,uiP.tesseractEditor.frame.size.width,uiP.tesseractEditor.frame.size.height);
    [UIView commitAnimations]; 
    uiP=nil;
}

-(void) backClick:(id) sender
{
    [self hide];
}

-(void) OCRClick:(id) sender
{
    if([pageType isEqualToString:@"1"]){
        [self sendNotification:[TTMBProgressHUDMediator SHOW]];
    }else{
        [self sendNotification:[TTMBProgressHUDMediator SHOW]];
    }
    
    
//    _string(1,[NSThread currentThread].isMainThread?@"YES":@"NO");
    //多线程处理
    [NSThread detachNewThreadSelector:@selector(threadMethod:) toTarget:self withObject:nil];
}

- (void) threadMethod:(id *)sender
{
    //12=英文
    //13=中文
    TTDataProxy *dataP=(TTDataProxy *)[self.facade retrieveProxy:[TTDataProxy NAME]];
    TTLanguageType type;
    if([dataP.languageType isEqualToString:NSLocalizedString(@"12", nil)]){
        type=English;
    }else{
        type=Chinese;
    }
    dataP=nil;
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    UIImage *image=[uiP.tesseractEditor getImage];
    TTTesseract *tes=[[TTTesseract alloc] initWithLanguageType:type];
    @try {
//        [NSException raise:@"aaaaaa" format:@"%@",@"aaaaaaa"];//抛出一个一场测试
        //开始识别
         NSString *str=[tes ocrProcessingWithImage:image];
        [self sendNotification:[TTMBProgressHUDMediator HIDE]];
        /*
         iOS开发中,在主线程之外的线程更新主线程所显示的UI界面元素,不能直接调用主线程的类的更新界面的方法.
         【错误信息】
         bool _WebTryThreadLock(bool), 0xe447b80: 
         Tried to obtain the web lock from a thread other than the main thread or the web thread. 
         This may be a result of calling to UIKit from a secondary thread. Crashing now...
         【解决办法】
         需要使用performSelectorOnMainThread,例如:
         [self performSelectorOnMainThread:@selector(updateLabel:) withObject:updateData waitUntilDone:YES];
         在updateLabel此方法中更新主线程所显示的UI界面元素即可.
         */
        [self performSelectorOnMainThread:@selector(onMainThread:) withObject:str waitUntilDone:YES];
    }
    @catch (NSException *exception) {
        [self sendNotification:[TTMBProgressHUDMediator HIDE]];
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:NSLocalizedString(@"27", nil)
                                                      message:NSLocalizedString(@"26", nil)
                                                     delegate:nil
                                            cancelButtonTitle:nil
                                            otherButtonTitles:NSLocalizedString(@"7", nil), nil];
        [alert show];
        [alert release],alert=nil;
    }
    [tes release],tes=nil;
    uiP=nil;
}

-(void) onMainThread:(id) sender
{
//    _string(1,[NSThread currentThread].isMainThread?@"YES":@"NO");
    [self sendNotification:[TTTextViewMediator SHOW] body:(NSString *)sender type:pageType];
}

-(void) languageClick:(id) sender
{
    [self sendNotification:[TTLanguageMediator SHOW] body:nil type:pageType];
}

- (void)animationDidStop:(NSString *)animationID
                finished:(NSNumber *)finished 
                 context:(void *)context
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    [uiP.tesseractEditor.back removeTarget:self 
                                       action:@selector(backClick:) 
                             forControlEvents:UIControlEventTouchUpInside];
    [uiP.tesseractEditor.OCR removeTarget:self 
                                      action:@selector(OCRClick:) 
                            forControlEvents:UIControlEventTouchUpInside];
    [uiP.tesseractEditor.language removeTarget:self 
                                           action:@selector(languageClick:) 
                                 forControlEvents:UIControlEventTouchUpInside];
    [uiP.tesseractEditor removeFromSuperview];
    [uiP.tesseractEditor release],uiP.tesseractEditor=nil;
    uiP=nil;
    _float(2,[TTUtil availableMemory],[TTUtil usedMemory]);
}

@end
