//
//  TTTextViewMediator.m
//  TextOCR
//
//  Created by MingFanWang on 13-1-24.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "TTTextViewMediator.h"
#import "TTUIProxy.h"
#import "TTImageAlertViewMediator.h"

@implementation TTTextViewMediator

#pragma mark
#pragma mark 类方法
+(NSString *) NAME
{
    return @"TTTextViewMediator";
}

+(NSString *) SHOW
{
    return @"TTTextViewMediatorShow";
}

+(NSString *) HIDE
{
    return @"TTTextViewMediatorHide";
}


#pragma mark
#pragma mark 重写父类的方法
-(void)initializeMediator
{
    
}

-(NSArray *)listNotificationInterests
{
    return [NSArray arrayWithObjects:
            [TTTextViewMediator SHOW],
            [TTTextViewMediator HIDE],
            nil];
}

-(void)handleNotification:(id<INotification>) note
{
    if([[note name] isEqualToString:[TTTextViewMediator SHOW]]){
        pageType=(NSString*)[note type];
        [self show:(NSString *)[note body]];
    }else if([[note name] isEqualToString:[TTTextViewMediator HIDE]]){
        [self hide];
    }
}

#pragma mark
#pragma mark 私有方法

-(void) show:(NSString *) text
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    //创建
    if([pageType isEqualToString:@"1"]){
        uiP.textView=[[TTTextView alloc] initWithFrame:CGRectMake(MainWidth,20.0,MainWidth,MainHeight)];
        [uiP.picker.view addSubview:uiP.textView];
    }else{
        uiP.textView=[[TTTextView alloc] initWithFrame:CGRectMake(MainWidth,0,MainWidth,MainHeight)];
        [[uiP appView] addSubview:uiP.textView];
    }
    [uiP.textView.back addTarget:self action:@selector(backClick:) forControlEvents:UIControlEventTouchUpInside];   
    [uiP.textView.image addTarget:self action:@selector(imageClick:) forControlEvents:UIControlEventTouchUpInside];
    [uiP.textView setMultiTextText:text];
    [uiP.textView setMultiTextDelegate:self];
    [uiP.textView setScaleImage:[uiP.tesseractEditor getImage]];
    //开始动画
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    uiP.tesseractEditor.frame=CGRectMake(-MainWidth,uiP.tesseractEditor.frame.origin.y,uiP.tesseractEditor.frame.size.width,uiP.tesseractEditor.frame.size.height);
    uiP.textView.frame=CGRectMake(0, uiP.textView.frame.origin.y, uiP.textView.frame.size.width,uiP.textView.frame.size.height);
    [UIView commitAnimations];
    uiP=nil;
    _float(2,[TTUtil availableMemory],[TTUtil usedMemory]);
}

-(void) hide
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    //动画
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
    [UIView setAnimationDuration:0.3f];
    uiP.tesseractEditor.frame=CGRectMake(0,uiP.tesseractEditor.frame.origin.y,uiP.tesseractEditor.frame.size.width,uiP.tesseractEditor.frame.size.height);
    uiP.textView.frame=CGRectMake(MainWidth, uiP.textView.frame.origin.y, uiP.textView.frame.size.width,uiP.textView.frame.size.height);
    [UIView commitAnimations]; 
    uiP=nil;
}

- (void)animationDidStop:(NSString *)animationID
                finished:(NSNumber *)finished 
                 context:(void *)context
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    [uiP.textView.back removeTarget:self 
                             action:@selector(backClick:) 
                   forControlEvents:UIControlEventTouchUpInside]; 
    [uiP.textView.image removeTarget:self 
                              action:@selector(imageClick:) 
                    forControlEvents:UIControlEventTouchUpInside];
    [uiP.textView removeFromSuperview];
    [uiP.textView release],uiP.textView=nil;
    uiP=nil; 
    _float(2,[TTUtil availableMemory],[TTUtil usedMemory]);
}

-(void) backClick:(id) sender
{
    [self hide];
}

-(void) imageClick:(id) sender
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    [uiP.textView animationImage];
    uiP=nil;
}

#pragma mark
#pragma mark UITextViewDelegate
- (BOOL) textView:(UITextView *)textView 
shouldChangeTextInRange:(NSRange)range
        replacementText:(NSString *)text
{
    if([text isEqualToString:@"\n"]){
        [textView resignFirstResponder];//放弃第一响应者
        return NO;
    }
    return YES;
}

@end
