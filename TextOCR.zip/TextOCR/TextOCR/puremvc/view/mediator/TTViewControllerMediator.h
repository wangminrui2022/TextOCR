//
//  TTViewControllerMediator.h
//  TextOCR
//
//  Created by MingFanWang on 12-10-7.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "Mediator.h"

@interface TTViewControllerMediator : Mediator
<UINavigationControllerDelegate,UIImagePickerControllerDelegate>
{
   
}

+(NSString *) NAME;
+(NSString *) START;

@end
