//
//  TTViewControllerMediator.m
//  TextOCR
//
//  Created by 王明凡 on 12-10-7.
//  Copyright (c) 2012年 王明凡. All rights reserved.
//

#import "TTViewControllerMediator.h"
#import "TTUIProxy.h"
#import "TTCameraControlsMediator.h"
#import "TTImageEditingControlsMediator.h"
#import "TTImageEditingMediator.h"
#import "TTPictureLibraryMediator.h"
#import "TTInfoMediator.h"

@implementation TTViewControllerMediator

#pragma mark
#pragma mark 类方法
+(NSString *) NAME
{
    return @"TTViewControllerMediator";
}

+(NSString *) START
{
    return @"TTViewControllerMediatorStart";
}

#pragma mark
#pragma mark 重写父类的方法
-(void)initializeMediator
{
    
}

-(NSArray *)listNotificationInterests
{
    return [NSArray arrayWithObjects:[TTViewControllerMediator START],nil];
}

-(void)handleNotification:(id<INotification>) note
{
    if([[note name] isEqualToString:[TTViewControllerMediator START]]){
        [self start];
    }
}

#pragma mark
#pragma mark 私有方法

-(void) takePictureClick:(id) sender
{
    //是否有后置摄像头
    if([UIImagePickerController isCameraDeviceAvailable:UIImagePickerControllerCameraDeviceRear]){
        TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
        //创建摄像头
        if(uiP.picker==nil){
            uiP.picker = [[UIImagePickerController alloc] init];
        }
        //摄像头属性
        uiP.picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        uiP.picker.delegate = self;
        uiP.picker.allowsEditing=NO;
        uiP.picker.showsCameraControls = NO;
        //显示摄像机控制
        [self sendNotification:[TTCameraControlsMediator SHOW]];
        //显示摄像头
        [[uiP appViewController] presentModalViewController:uiP.picker animated:YES];
        uiP=nil;
    }
}

-(void) pictureClick:(id) sender
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    //创建图库
    if(uiP.picker==nil){
        uiP.picker = [[UIImagePickerController alloc] init];
    }
    //显示图库
    uiP.picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    uiP.picker.delegate = self;
    [[uiP appViewController] presentModalViewController:uiP.picker animated:YES];
    uiP=nil;
}

-(void) libraryClick:(id) sender
{
    [self sendNotification:[TTPictureLibraryMediator SHOW]];
}

-(void) infoClick:(id) sender
{
    [self sendNotification:[TTInfoMediator SHOW]];
}

-(void) start
{
    TTUIProxy *uiP=(TTUIProxy *)[self.facade retrieveProxy:[TTUIProxy NAME]];
    [[uiP appViewController].takePicture addTarget:self 
                                            action:@selector(takePictureClick:) 
                                  forControlEvents:UIControlEventTouchUpInside];
    [[uiP appViewController].picture addTarget:self 
                                        action:@selector(pictureClick:) 
                              forControlEvents:UIControlEventTouchUpInside];
    [[uiP appViewController].library addTarget:self 
                                        action:@selector(libraryClick:) 
                              forControlEvents:UIControlEventTouchUpInside];
    [[uiP appViewController].info addTarget:self 
                                     action:@selector(infoClick:) 
                           forControlEvents:UIControlEventTouchUpInside];
    uiP=nil;
}

#pragma mark
#pragma mark UIImagePickerControllerDelegate
-(void)imagePickerController:(UIImagePickerController*)picker 
didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info valueForKey:UIImagePickerControllerOriginalImage];
    [self sendNotification:[TTImageEditingMediator SHOW] body:image];
    //[self sendNotification:[TTImageEditingControlsMediator SHOW]];
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self sendNotification:[TTCameraControlsMediator HIDE]];
}

@end
