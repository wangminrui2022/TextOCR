//
//  TTCameraControls.h
//  TextOCR
//
//  Created by MingFanWang on 12-10-20.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

@interface TTCameraControls : UIView
{
    UIImageView *backgroundImage;
}
@property (nonatomic,retain) UIButton *cancel;
@property (nonatomic,retain) UIButton *takePicture;
@property (nonatomic,retain) UIButton *light;

-(id) initWithContainerHeight:(CGFloat) containerHeight;

@end
