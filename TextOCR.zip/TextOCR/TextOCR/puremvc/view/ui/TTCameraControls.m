//
//  TTCameraControls.m
//  TextOCR
//
//  Created by 王明凡 on 12-10-20.
//  Copyright (c) 2012年 王明凡. All rights reserved.
//

#import "TTCameraControls.h"
#import "TTImage.h"

@implementation TTCameraControls

@synthesize cancel=_cancel;
@synthesize takePicture=_takePicture;
@synthesize light=_light;

#pragma mark
#pragma mark 公共方法
-(id) initWithContainerHeight:(CGFloat) containerHeight
{
    self=[super init];
    if(self)
    {
        //背景图片
        UIImage *bImage=[TTImage imageNamed:@"BottomBar54.png"];
        backgroundImage=[[UIImageView alloc] initWithImage:bImage];
        [self addSubview:backgroundImage];
        //设置当前容器frame,底部位置
        [self setFrame:CGRectMake(0,
                                  containerHeight-backgroundImage.frame.size.height,
                                  backgroundImage.frame.size.width,
                                  backgroundImage.frame.size.height)];
        //取消按钮
        UIImage *cancelImage=[TTImage imageNamed:@"cancel.png"];
        self.cancel=[[UIButton alloc] init];
        self.cancel=[[UIButton alloc] initWithFrame:CGRectMake(10.0,
                                                             (self.frame.size.height-cancelImage.size.height)/2,
                                                             cancelImage.size.width,
                                                             cancelImage.size.height)];
        [self.cancel setBackgroundImage:cancelImage forState:UIControlStateNormal];
        [self addSubview:self.cancel];
        //拍照按钮
        UIImage *takePictureImage=[TTImage imageNamed:@"camera.png"];
        self.takePicture=[[UIButton alloc] initWithFrame:CGRectMake((self.frame.size.width-takePictureImage.size.width)/2,
                                                               (self.frame.size.height-takePictureImage.size.height)/2,
                                                               takePictureImage.size.width,
                                                               takePictureImage.size.height)];
        [self.takePicture setBackgroundImage:takePictureImage forState:UIControlStateNormal];
        [self addSubview:self.takePicture];
        //切换摄像头
        UIImage *lightImage=[TTImage imageNamed:@"light.png"];
        self.light=[[UIButton alloc] initWithFrame:CGRectMake(self.frame.size.width-lightImage.size.width-10,
                                                                (self.frame.size.height-lightImage.size.height)/2,
                                                                lightImage.size.width,
                                                                lightImage.size.height)];
        [self.light setBackgroundImage:lightImage forState:UIControlStateNormal];
        [self addSubview:self.light];
    }
    return self;
}

-(void) dealloc
{
    [backgroundImage release],backgroundImage=nil;
    [self.cancel release],self.cancel=nil;
    [_cancel release],_cancel=nil;
    [self.takePicture release],self.takePicture=nil;
    [_takePicture release],_takePicture=nil;
    [self.light release],self.light=nil;
    [_light release],_light=nil;
    [super dealloc];
}

@end
