//
//  TTCubeBottom.h
//  TextOCR
//
//  Created by MingFanWang on 13-7-29.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

//1=状态1，2=状态2
#define TTCUBEBOTTOM_STATE1 1
#define TTCUBEBOTTOM_STATE2 2

@interface TTCubeBottom : UIView
{
    UIImageView *bottomBar;
    int selectStatus;
}
@property (nonatomic,retain) UIView *state1Container;
@property (nonatomic,retain) UIView *state2Container;
@property (nonatomic,retain) UIButton *back;
@property (nonatomic,retain) UIButton *OCR;
@property (nonatomic,retain) UIButton *done;
@property (nonatomic,retain) UIButton *cancel;

-(void) setSelectStatus1;
-(void) setSelectStatus2;
-(int) getSelectStatus;

@end
