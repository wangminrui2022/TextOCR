//
//  TTCubeBottom.m
//  TextOCR
//
//  Created by 王明凡 on 13-7-29.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

#import "TTCubeBottom.h"
#import "TTImage.h"

@implementation TTCubeBottom

@synthesize state1Container=_state1Container;
@synthesize state2Container=_state2Container;
@synthesize back=_back;
@synthesize OCR=_OCR;
@synthesize done=_done;
@synthesize cancel=_cancel;

- (id)init
{
    self = [super init];
    if (self) {
        //下工具条
        UIImage *bImage=[TTImage imageNamed:@"BottomBar54.png"];
        bottomBar=[[UIImageView alloc] initWithImage:bImage];
        [self addSubview:bottomBar];
        //设置当前对象frame
        [self setFrame:bottomBar.frame];
        //状态1容器
        self.state1Container=[[UIView alloc] initWithFrame:bottomBar.frame];
        [self addSubview:self.state1Container];
        //返回
        UIImage *backImage=[TTImage imageNamed:@"button.png"];
        self.back=[[UIButton alloc] initWithFrame:CGRectMake(10.0,
                                                             (bottomBar.frame.size.height-backImage.size.height)/2,
                                                             backImage.size.width,
                                                             backImage.size.height)];
        [self.back.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [self.back setTitle:NSLocalizedString(@"7", nil) forState:UIControlStateNormal];
        [self.back setBackgroundImage:backImage forState:UIControlStateNormal];
        [self.state1Container addSubview:self.back];
        //识别
        UIImage *OCRImage=[TTImage imageNamed:@"button.png"];
        self.OCR=[[UIButton alloc] initWithFrame:CGRectMake(bottomBar.frame.size.width-OCRImage.size.width-10,
                                                            (bottomBar.frame.size.height-OCRImage.size.height)/2,
                                                            OCRImage.size.width,
                                                            OCRImage.size.height)];
        [self.OCR.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [self.OCR setTitle:NSLocalizedString(@"10", nil) forState:UIControlStateNormal];
        [self.OCR setBackgroundImage:OCRImage forState:UIControlStateNormal];
        [self.state1Container addSubview:self.OCR];
        //状态2容器
        self.state2Container=[[UIView alloc] initWithFrame:bottomBar.frame];
        self.state2Container.hidden=YES;
        [self addSubview:self.state2Container];
        //取消
        UIImage *cancelImage=[TTImage imageNamed:@"button.png"];
        self.cancel=[[UIButton alloc] initWithFrame:CGRectMake(10.0,
                                                           (bottomBar.frame.size.height-cancelImage.size.height)/2,
                                                           cancelImage.size.width,
                                                           cancelImage.size.height)];
        [self.cancel.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [self.cancel setTitle:NSLocalizedString(@"3", nil) forState:UIControlStateNormal];
        [self.cancel setBackgroundImage:cancelImage forState:UIControlStateNormal];
        [self.state2Container addSubview:self.cancel];
        //完成
        UIImage *doneImage=[TTImage imageNamed:@"button.png"];
        self.done=[[UIButton alloc] initWithFrame:CGRectMake(bottomBar.frame.size.width-doneImage.size.width-10,
                                                            (bottomBar.frame.size.height-doneImage.size.height)/2,
                                                            doneImage.size.width,
                                                            doneImage.size.height)];
        [self.done.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [self.done setTitle:NSLocalizedString(@"4", nil) forState:UIControlStateNormal];
        [self.done setBackgroundImage:doneImage forState:UIControlStateNormal];
        [self.state2Container addSubview:self.done];
        //初始化为状态1
        selectStatus=TTCUBEBOTTOM_STATE1;
    }
    return self;
}

-(void) dealloc
{
    [bottomBar release],bottomBar=nil;
    [self.state1Container release],self.state1Container=nil;
    [_state1Container release],_state1Container=nil;
    [self.state2Container release],self.state2Container=nil;
    [_state2Container release],_state2Container=nil;
    [self.back release],self.back=nil;
    [_back release],_back=nil;
    [self.OCR release],self.OCR=nil;
    [_OCR release],_OCR=nil;
    [self.done release],self.done=nil;
    [_done release],_done=nil;
    [self.cancel release],self.cancel=nil;
    [_cancel release],_cancel=nil;
    [super dealloc];
}

-(void) setSelectStatus1
{
    selectStatus=TTCUBEBOTTOM_STATE1;
    /*
     实现iphone漂亮的动画效果主要有两种方法:
     一种是UIView层面的
     一种是使用CATransition进行更低层次的控制
     *注：该动画是当前对象(TTCubeBottom)整体翻转
     */
    CATransition *animation = [CATransition animation];
    animation.delegate = self;
    animation.duration = 0.5f;
    animation.timingFunction = UIViewAnimationCurveEaseInOut;
	animation.fillMode = kCAFillModeForwards;
    /* 过渡效果
     fade                   交叉淡化过渡(不支持过渡方向)
     push                   新视图把旧视图推出去
     moveIn                 新视图移到旧视图上面
     reveal                 将旧视图移开,显示下面的新视图
     cube                   立方体翻滚效果
     oglFlip                上下左右翻转效果
     suckEffect             收缩效果，如一块布被抽走(不支持过渡方向)
     rippleEffect           滴水效果(不支持过渡方向)
     pageCurl               向上翻页效果
     pageUnCurl             向下翻页效果
     cameraIrisHollowOpen   相机镜头打开效果(不支持过渡方向)
     cameraIrisHollowClose  相机镜头关上效果(不支持过渡方向)
     */
	animation.type=@"cube";
    /* 过渡方向
     fromRight
     fromLeft
     fromTop
     fromBottom
     */
    animation.subtype=@"fromTop";
    //交换指定子视图深度索引
    [self exchangeSubviewAtIndex:1 withSubviewAtIndex:2];
    //显示和隐藏容器
    self.state1Container.hidden=NO;
    self.state2Container.hidden=YES;
    [self.layer addAnimation:animation forKey:@"animation"];
}

-(void) setSelectStatus2
{
    selectStatus=TTCUBEBOTTOM_STATE2;
    CATransition *animation = [CATransition animation];
    animation.delegate = self;
    animation.duration = 0.5f;
    animation.timingFunction = UIViewAnimationCurveEaseInOut;
	animation.fillMode = kCAFillModeForwards;
	animation.type=@"cube";
    animation.subtype=@"fromTop";
    [self exchangeSubviewAtIndex:1 withSubviewAtIndex:2];
    self.state1Container.hidden=YES;
    self.state2Container.hidden=NO;
    [self.layer addAnimation:animation forKey:@"animation"];
}

-(int) getSelectStatus
{
    return selectStatus;
}

@end
