//
//  TTImage.h
//  TextOCR
//
//  Created by 王明凡 on 13-7-29.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

@interface TTImage : UIImage

@end
