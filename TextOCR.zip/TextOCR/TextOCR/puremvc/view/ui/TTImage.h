//
//  TTImage.h
//  TextOCR
//
//  Created by MingFanWang on 13-7-29.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

@interface TTImage : UIImage

@end
