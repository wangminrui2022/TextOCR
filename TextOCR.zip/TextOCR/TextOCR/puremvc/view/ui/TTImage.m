//
//  TTImage.m
//  TextOCR
//  
//  Created by MingFanWang on 13-7-29.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//
//  UIImage的imageNamed方法它所占用的内容不被释放，即使其所在的view已经release了，即使release掉 UIImageView也无济于事。
//  所以推荐使用+(UIImage *)imageWithContentsOfFile:(NSString *)path方法加载图片。

#import "TTImage.h"

@implementation TTImage

+(UIImage *)imageNamed:(NSString *)name {
    
    return [UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/%@", [[NSBundle mainBundle] bundlePath], name]];
} 

@end
