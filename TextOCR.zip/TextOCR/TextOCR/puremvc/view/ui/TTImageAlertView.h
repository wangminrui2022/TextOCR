//
//  TTImageAlertView.h
//  TextOCR
//
//  Created by MingFanWang on 13-1-27.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "TTScrollView.h"

@interface TTImageAlertView : UIAlertView
{
    TTScrollView *scrollView;
}

-(void) addImage:(UIImage *) image;

@end
