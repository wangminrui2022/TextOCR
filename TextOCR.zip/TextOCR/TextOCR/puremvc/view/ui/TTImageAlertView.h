//
//  TTImageAlertView.h
//  TextOCR
//
//  Created by 王明凡 on 13-1-27.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

#import "TTScrollView.h"

@interface TTImageAlertView : UIAlertView
{
    TTScrollView *scrollView;
}

-(void) addImage:(UIImage *) image;

@end
