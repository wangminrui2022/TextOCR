//
//  TTImageAlertView.m
//  TextOCR
//
//  Created by MingFanWang on 13-1-27.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "TTImageAlertView.h"

@implementation TTImageAlertView

#pragma mark
#pragma mark 公共方法
-(void) layoutSubviews
{
    CGRect rect = self.bounds;
    rect.size.height += 300;
    self.bounds = rect;
    for (UIView *view in self.subviews){
        _string(1,view);
        //如果子类是TTScrollView
        if([view isKindOfClass:[TTScrollView class]]){
            TTScrollView *scr=(TTScrollView *)view;
            scr.frame=CGRectMake(11.0,45.0,rect.size.width-22.0,305.0);
            [scr setMaxMinZoomScalesForCurrentBounds];//重新设置frame后,设置最大和最小缩放比例
            
        }else if([view isKindOfClass:[UIButton class]]){
            view.frame=CGRectMake(view.frame.origin.x, 
                                  rect.size.height-view.frame.size.height-15.0, 
                                  view.frame.size.width, 
                                  view.frame.size.height);
        }
    }

}

-(void) addImage:(UIImage *) image
{
    if(scrollView==nil){
        scrollView=[[TTScrollView alloc] initWithFrame:CGRectZero image:image];
        [self addSubview:scrollView];
    }
}

@end
