//
//  TTImageEditTop.h
//  TextOCR
//
//  Created by 王明凡 on 13-7-29.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

#define TTIMAGEEDITTOP_CROP 1
#define TTIMAGEEDITTOP_BRIGHTNESS 2
#define TTIMAGEEDITTOP_BLACKWHITE 3
#define TTIMAGEEDITTOP_ROTATE_TO_LEFT 4
#define TTIMAGEEDITTOP_ROTATE_TO_RIGHT 5
#define TTIMAGEEDITTOP_CLICK @"TTImageEditTop_Click"

@interface TTImageEditTop : UIView
{
    UIImageView *topBar;
    int selectStatus; 
}
@property (nonatomic,retain) UIButton *crop;
@property (nonatomic,retain) UIButton *brightness;
@property (nonatomic,retain) UIButton *blackWhite;
@property (nonatomic,retain) UIButton *rotateToLeft;
@property (nonatomic,retain) UIButton *rotateToRight;

-(void) setSelectStatus:(int) value;
-(int) getSelectStatus;

@end
