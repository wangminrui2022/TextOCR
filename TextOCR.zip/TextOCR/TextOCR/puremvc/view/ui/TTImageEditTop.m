//
//  TTImageEditTop.m
//  TextOCR
//
//  Created by MingFanWang on 13-7-29.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "TTImageEditTop.h"
#import "TTImage.h"

@implementation TTImageEditTop

@synthesize crop=_crop;
@synthesize brightness=_brightness;
@synthesize blackWhite=_blackWhite;
@synthesize rotateToLeft=_rotateToLeft;
@synthesize rotateToRight=_rotateToRight;

#pragma mark
#pragma mark 公共方法
-(id)init
{
    self = [super init];
    if (self) {
        //上工具条
        UIImage *tImage=[TTImage imageNamed:@"TopBar.png"];
        topBar=[[UIImageView alloc] initWithImage:tImage];
        [self addSubview:topBar];
        //设置当前对象frame
        [self setFrame:topBar.frame];
        //裁剪
        UIImage *cropImage=[TTImage imageNamed:@"crop.png"];
        self.crop=[[UIButton alloc] initWithFrame:CGRectMake(0,0,cropImage.size.width,cropImage.size.height)];
        [self.crop setBackgroundImage:cropImage forState:UIControlStateNormal];
        [self addSubview:self.crop];
        //亮度调整
        UIImage *brightnessImage=[TTImage imageNamed:@"brightness.png"];
        self.brightness=[[UIButton alloc] initWithFrame:CGRectMake(0,0,brightnessImage.size.width,brightnessImage.size.height)];
        [self.brightness setBackgroundImage:brightnessImage forState:UIControlStateNormal];
        [self addSubview:self.brightness];
        //黑白处理
        UIImage *blackWhiteImage=[TTImage imageNamed:@"blackWhite.png"];
        self.blackWhite=[[UIButton alloc] initWithFrame:CGRectMake(0,0,blackWhiteImage.size.width,blackWhiteImage.size.height)];
        [self.blackWhite setBackgroundImage:blackWhiteImage forState:UIControlStateNormal];
        [self addSubview:self.blackWhite];
        //旋转左
        UIImage *rotateToLeftImage=[TTImage imageNamed:@"left.png"];
        self.rotateToLeft=[[UIButton alloc] initWithFrame:CGRectMake(0,0,rotateToLeftImage.size.width,rotateToLeftImage.size.height)];
        [self.rotateToLeft setBackgroundImage:rotateToLeftImage forState:UIControlStateNormal];
        [self addSubview:self.rotateToLeft];
        //旋转右
        UIImage *rotateToRightImage=[TTImage imageNamed:@"right.png"];
        self.rotateToRight=[[UIButton alloc] initWithFrame:CGRectMake(0,0,rotateToRightImage.size.width,rotateToRightImage.size.height)];
        [self.rotateToRight setBackgroundImage:rotateToRightImage forState:UIControlStateNormal];
        [self addSubview:self.rotateToRight];
        //位置
        CGFloat topBarH=topBar.frame.size.height;
        CGFloat cropW=self.crop.frame.size.width;
        CGFloat cropH=self.crop.frame.size.height;
        CGFloat brightnessW=self.brightness.frame.size.width;
        CGFloat brightnessH=self.brightness.frame.size.height;
        CGFloat blackWhiteW=self.blackWhite.frame.size.width;
        CGFloat blackWhiteH=self.blackWhite.frame.size.height;
        CGFloat rotateToLeftW=self.rotateToLeft.frame.size.width;
        CGFloat rotateToLeftH=self.rotateToLeft.frame.size.height;
        CGFloat rotateToRightW=self.rotateToRight.frame.size.width;
        CGFloat rotateToRightH=self.rotateToRight.frame.size.height;
        self.crop.frame=CGRectMake(10.0, (topBarH-cropH)/2, cropW, cropH);
        self.brightness.frame=CGRectMake(self.crop.frame.origin.x+cropW+20, (topBarH-brightnessH)/2, brightnessW, brightnessH);
        self.blackWhite.frame=CGRectMake(self.brightness.frame.origin.x+brightnessW+20, (topBarH-blackWhiteH)/2, blackWhiteW, blackWhiteH);
        self.rotateToLeft.frame=CGRectMake(self.blackWhite.frame.origin.x+blackWhiteW+20, (topBarH-rotateToLeftH)/2, rotateToLeftW, rotateToLeftH);
        self.rotateToRight.frame=CGRectMake(self.rotateToLeft.frame.origin.x+rotateToLeftW+20, (topBarH-rotateToRightH)/2, rotateToRightW, rotateToRightH);
        //事件
        [self.crop addTarget:self
                      action:@selector(cropClick:)
            forControlEvents:UIControlEventTouchUpInside];
        [self.brightness addTarget:self
                            action:@selector(brightnessClick:)
                  forControlEvents:UIControlEventTouchUpInside];
        [self.blackWhite addTarget:self
                            action:@selector(blackWhiteClick:)
                  forControlEvents:UIControlEventTouchUpInside];
        [self.rotateToLeft addTarget:self
                              action:@selector(rotateToLeftClick:)
                    forControlEvents:UIControlEventTouchUpInside];
        [self.rotateToRight addTarget:self
                               action:@selector(rotateToRightClick:)
                     forControlEvents:UIControlEventTouchUpInside];
        //
        selectStatus=0;
    }
    return self;
}

-(void) dealloc
{
    [self.crop removeTarget:self
                     action:@selector(cropClick:)
           forControlEvents:UIControlEventTouchUpInside];
    [self.brightness removeTarget:self
                           action:@selector(brightnessClick:)
                 forControlEvents:UIControlEventTouchUpInside];
    [self.blackWhite removeTarget:self
                           action:@selector(blackWhiteClick:)
                 forControlEvents:UIControlEventTouchUpInside];
    [self.rotateToLeft removeTarget:self
                             action:@selector(rotateToLeftClick:)
                   forControlEvents:UIControlEventTouchUpInside];
    [self.rotateToRight removeTarget:self
                              action:@selector(rotateToRightClick:)
                    forControlEvents:UIControlEventTouchUpInside];
    [topBar release],topBar=nil;
    [self.crop release],self.crop=nil;
    [_crop release],_crop=nil;
    [self.brightness release],self.brightness=nil;
    [_brightness release],_brightness=nil;
    [self.blackWhite release],self.blackWhite=nil;
    [_blackWhite release],_blackWhite=nil;
    [self.rotateToLeft release],self.rotateToLeft=nil;
    [_rotateToLeft release],_rotateToLeft=nil;
    [self.rotateToRight release],self.rotateToRight=nil;
    [_rotateToRight release],_rotateToRight=nil;
    [super dealloc];
}

-(void) setSelectStatus:(int) value
{
    selectStatus=value;
}

-(int) getSelectStatus
{
    return selectStatus;
}

-(void) cropClick:(id) sender
{
     selectStatus=TTIMAGEEDITTOP_CROP;
    [[NSNotificationCenter defaultCenter] postNotificationName:TTIMAGEEDITTOP_CLICK object:sender];
}

-(void) brightnessClick:(id) sender
{
    selectStatus=TTIMAGEEDITTOP_BRIGHTNESS;
    [[NSNotificationCenter defaultCenter] postNotificationName:TTIMAGEEDITTOP_CLICK object:sender];
}

-(void) blackWhiteClick:(id) sender
{
    selectStatus=TTIMAGEEDITTOP_BLACKWHITE;
    [[NSNotificationCenter defaultCenter] postNotificationName:TTIMAGEEDITTOP_CLICK object:sender];
}

-(void) rotateToLeftClick:(id) sender
{
    selectStatus=TTIMAGEEDITTOP_ROTATE_TO_LEFT;
    [[NSNotificationCenter defaultCenter] postNotificationName:TTIMAGEEDITTOP_CLICK object:sender];
}

-(void) rotateToRightClick:(id) sender
{
    selectStatus=TTIMAGEEDITTOP_ROTATE_TO_RIGHT;
    [[NSNotificationCenter defaultCenter] postNotificationName:TTIMAGEEDITTOP_CLICK object:sender];
}

@end
