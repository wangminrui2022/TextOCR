//
//  TTImageEditing.h
//  TextOCR
//
//  Created by 王明凡 on 12-10-21.
//  Copyright (c) 2012年 王明凡. All rights reserved.
//

#import "TTScrollView.h"
#import "TTImageEditTop.h"
#import "TTCubeBottom.h"

@interface TTImageEditing : UIView
{

}
@property (nonatomic,retain) TTImageEditTop *topBar;
@property (nonatomic,retain) TTScrollView *editImage;
@property (nonatomic,retain) TTCubeBottom *bottomBar;


-(id)initWithFrame:(CGRect)frame image:(UIImage*) image;
-(void) setScaleImage:(UIImage*) image;

@end
