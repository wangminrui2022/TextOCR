//
//  TTImageEditing.h
//  TextOCR
//
//  Created by MingFanWang on 12-10-21.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "TTScrollView.h"
#import "TTImageEditTop.h"
#import "TTCubeBottom.h"

@interface TTImageEditing : UIView
{

}
@property (nonatomic,retain) TTImageEditTop *topBar;
@property (nonatomic,retain) TTScrollView *editImage;
@property (nonatomic,retain) TTCubeBottom *bottomBar;


-(id)initWithFrame:(CGRect)frame image:(UIImage*) image;
-(void) setScaleImage:(UIImage*) image;

@end
