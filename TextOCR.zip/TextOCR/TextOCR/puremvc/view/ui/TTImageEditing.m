//
//  TTImageEditing.m
//  TextOCR
//
//  Created by MingFanWang on 12-10-21.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "TTImageEditing.h"
#import "TTImage.h"

@implementation TTImageEditing

@synthesize topBar=_topBar;
@synthesize editImage=_editImage;
@synthesize bottomBar=_bottomBar;

#pragma mark
#pragma mark 公共方法
-(id)initWithFrame:(CGRect)frame image:(UIImage*) image
{
    self = [super initWithFrame:frame];
    if (self) {
        //上工具条
        self.topBar=[[TTImageEditTop alloc] init];
        [self addSubview:self.topBar];
         //下工具条
        self.bottomBar=[[TTCubeBottom alloc] init];
        [self addSubview:self.bottomBar];
        self.bottomBar.frame=CGRectMake(0,
                                        self.frame.size.height-self.bottomBar.frame.size.height,
                                        self.bottomBar.frame.size.width,
                                        self.bottomBar.frame.size.height);
        //图片显示
        self.editImage=[[TTScrollView alloc] initWithFrame:CGRectMake(0,
                                                                 self.topBar.frame.size.height,
                                                                 self.frame.size.width,
                                                                 self.frame.size.height-self.topBar.frame.size.height-self.bottomBar.frame.size.height)
                                                     image:image];
        [self insertSubview:self.editImage atIndex:0];//放置最低层
    }
    return self;
}

-(void) dealloc
{
    [self.topBar release],self.topBar=nil;
    [_topBar release],_topBar=nil;
    [self.bottomBar release],self.bottomBar=nil;
    [_bottomBar release],_bottomBar=nil;
    [self.editImage release],self.editImage=nil;
    [_editImage release],_editImage=nil;
    [super dealloc];
}

-(void) setScaleImage:(UIImage*) image
{
     [self.editImage setScaleImage:image];
}


@end
