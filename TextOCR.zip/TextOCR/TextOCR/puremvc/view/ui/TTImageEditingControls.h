//
//  TTImageEditingControls.h
//  TextOCR
//
//  Created by MingFanWang on 12-11-4.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

@interface TTImageEditingControls : UIView
{
    UIImageView *backgroundImage;
}

@property (nonatomic,retain) UIButton *back;
@property (nonatomic,retain) UIButton *select;
@property (nonatomic,retain) UIButton *OCR;

@end
