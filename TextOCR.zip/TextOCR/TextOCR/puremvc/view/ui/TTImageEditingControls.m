//
//  TTImageEditingControls.m
//  TextOCR
//
//  Created by MingFanWang on 12-11-4.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "TTImageEditingControls.h"

@implementation TTImageEditingControls

@synthesize back=_back;
@synthesize select=_select;
@synthesize OCR=_OCR;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //背景图片
        backgroundImage=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width,self.frame.size.height)];
        UIImage *bImage=[[UIImage alloc] initWithContentsOfFile:[TTUtil AbsolutePathWithFileName:@"BottomBar.png"]];
        [backgroundImage setImage:bImage];
        [self addSubview:backgroundImage];
        [bImage release],bImage=nil;
        //
        UIImage *backImage=[[UIImage alloc] initWithContentsOfFile:[TTUtil AbsolutePathWithFileName:@"button.png"]];
        self.back=[[UIButton alloc] init];
        [self.back.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:14.0]];
        [self.back setTitle:NSLocalizedString(@"7", nil) forState:UIControlStateNormal];
        [self.back setBackgroundImage:backImage forState:UIControlStateNormal];
        self.back.frame=CGRectMake(5.0, 11.0, 60.0, 35.0);
        [self addSubview:self.back];
        [backImage release],backImage=nil;
        //
        UIImage *selectImage=[[UIImage alloc] initWithContentsOfFile:[TTUtil AbsolutePathWithFileName:@"button.png"]];
        self.select=[[UIButton alloc] init];
        [self.select.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:14.0]];
        [self.select setTitle:NSLocalizedString(@"6", nil) forState:UIControlStateNormal];
        [self.select setBackgroundImage:selectImage forState:UIControlStateNormal];
        self.select.frame=CGRectMake(130.0, 11.0, 60.0, 35.0);
        [self addSubview:self.select];
        [selectImage release],selectImage=nil;
        //
        UIImage *usedImage=[[UIImage alloc] initWithContentsOfFile:[TTUtil AbsolutePathWithFileName:@"button.png"]];
        self.OCR=[[UIButton alloc] init];
        [self.OCR.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:14.0]];
        [self.OCR setTitle:NSLocalizedString(@"10", nil) forState:UIControlStateNormal];
        [self.OCR setBackgroundImage:usedImage forState:UIControlStateNormal];
        self.OCR.frame=CGRectMake(255.0, 11.0, 60.0, 35.0);
        [self addSubview:self.OCR];
        [usedImage release],usedImage=nil;
        
    }
    return self;
}

-(void) dealloc
{
    [backgroundImage release],backgroundImage=nil;
    [self.back release],self.back=nil;
    [_back release],_back=nil;
    [self.select release],self.select=nil;
    [_select release],_select=nil;
    [self.OCR release],self.OCR=nil;
    [_OCR release],_OCR=nil;
    [super dealloc];
}


@end
