//
//  TTInfo.h
//  TextOCR
//
//  Created by 王明凡 on 13-1-20.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

@interface TTInfo : UIView
{
    UIImageView *topBar;
    UILabel *title;
}
@property (nonatomic,retain) UIButton *done;
@property (nonatomic,retain) UITableView *table;

@end
