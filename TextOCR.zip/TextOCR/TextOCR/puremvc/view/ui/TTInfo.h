//
//  TTInfo.h
//  TextOCR
//
//  Created by MingFanWang on 13-1-20.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

@interface TTInfo : UIView
{
    UIImageView *topBar;
    UILabel *title;
}
@property (nonatomic,retain) UIButton *done;
@property (nonatomic,retain) UITableView *table;

@end
