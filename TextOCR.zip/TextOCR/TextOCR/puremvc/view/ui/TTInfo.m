//
//  TTInfo.m
//  TextOCR
//
//  Created by MingFanWang on 13-1-20.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "TTInfo.h"
#import "TTImage.h"

@implementation TTInfo

@synthesize done=_done;
@synthesize table=_table;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //上工具条
        UIImage *tImage=[TTImage imageNamed:@"TopBar.png"];
        topBar=[[UIImageView alloc] initWithImage:tImage];
        [self addSubview:topBar];
        //标题
        title=[[UILabel alloc] initWithFrame:CGRectMake((topBar.frame.size.width-200.0)/2,
                                                        (topBar.frame.size.height-35.0)/2,
                                                        200.0, 35.0)];
        title.backgroundColor=[UIColor clearColor];
        title.textColor=[UIColor whiteColor];
        title.font=[UIFont boldSystemFontOfSize:20.0];
        title.textAlignment=UITextAlignmentCenter;
        title.text=NSLocalizedString(@"18", nil);
        [self addSubview:title];
        //完成按钮
        UIImage *doneImage=[TTImage imageNamed:@"button.png"];
        self.done=[[UIButton alloc] initWithFrame:CGRectMake(topBar.frame.size.width-doneImage.size.width-10,
                                                             (topBar.frame.size.height-doneImage.size.height)/2,
                                                             doneImage.size.width,
                                                             doneImage.size.height)];
        [self.done.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [self.done setTitle:NSLocalizedString(@"4", nil) forState:UIControlStateNormal];
        [self.done setBackgroundImage:doneImage forState:UIControlStateNormal];
        [self addSubview:self.done];
        //表格
        self.table=[[UITableView alloc] initWithFrame:CGRectMake(0,
                                                                 topBar.frame.size.height,
                                                                 self.frame.size.width,
                                                                 self.frame.size.height-topBar.frame.size.height)
                                                style:UITableViewStyleGrouped];//初始化为分组表
        [self addSubview:self.table];
    }
    return self;
}

-(void) dealloc
{
    [topBar release],topBar=nil;
    [title release],title=nil;
    [self.done release],self.done=nil;
    [_done release],_done=nil;
    [self.table release],self.table=nil;
    [_table release],_table=nil;
    [super dealloc];
}
@end
