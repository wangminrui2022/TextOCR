//
//  TTLanguage.h
//  TextOCR
//
//  Created by 王明凡 on 13-1-2.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

@interface TTLanguage : UIView
{
    UIImageView *topBar;
    UILabel *title;
}
@property (nonatomic,retain) UIButton *back;
@property (nonatomic,retain) UITableView *table;

@end
