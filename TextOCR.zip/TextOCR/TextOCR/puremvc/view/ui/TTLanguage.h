//
//  TTLanguage.h
//  TextOCR
//
//  Created by MingFanWang on 13-1-2.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

@interface TTLanguage : UIView
{
    UIImageView *topBar;
    UILabel *title;
}
@property (nonatomic,retain) UIButton *back;
@property (nonatomic,retain) UITableView *table;

@end
