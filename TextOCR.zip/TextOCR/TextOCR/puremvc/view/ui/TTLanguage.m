//
//  TTLanguage.m
//  TextOCR
//
//  Created by MingFanWang on 13-1-2.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "TTLanguage.h"
#import "TTImage.h"

@implementation TTLanguage

@synthesize back=_back;
@synthesize table=_table;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //上工具条
        UIImage *tImage=[TTImage imageNamed:@"TopBar.png"];
        topBar=[[UIImageView alloc] initWithImage:tImage];
        [self addSubview:topBar];
        //标题
        title=[[UILabel alloc] initWithFrame:CGRectMake((topBar.frame.size.width-200.0)/2,
                                                        (topBar.frame.size.height-35.0)/2,
                                                        200.0, 35.0)];
        title.backgroundColor=[UIColor clearColor];
        title.textColor=[UIColor whiteColor];    
        title.font=[UIFont boldSystemFontOfSize:20.0];
        title.textAlignment=UITextAlignmentCenter;
        title.text=NSLocalizedString(@"17", nil);
        [self addSubview:title];
        //返回按钮
        UIImage *backImage=[TTImage imageNamed:@"back.png"];
        self.back=[[UIButton alloc] initWithFrame:CGRectMake(10.0,
                                                             (topBar.frame.size.height-backImage.size.height)/2,
                                                             backImage.size.width,
                                                             backImage.size.height)];
        [self.back.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [self.back setTitle:NSLocalizedString(@"7", nil) forState:UIControlStateNormal];
        [self.back setBackgroundImage:backImage forState:UIControlStateNormal];
        [self addSubview:self.back];
        //语言表格
        self.table=[[UITableView alloc] init];
        self.table.frame=CGRectMake(0,
                                    topBar.frame.size.height,
                                    self.frame.size.width,
                                    self.frame.size.height-topBar.frame.size.height);
        [self addSubview:self.table];
    }
    return self;
}

-(void) dealloc
{
    [topBar release],topBar=nil;
    [title release],title=nil;
    [self.back release],self.back=nil;
    [_back release],_back=nil;
    [self.table release],self.table=nil;
    [_table release],_table=nil;
    [super dealloc];
}

@end
