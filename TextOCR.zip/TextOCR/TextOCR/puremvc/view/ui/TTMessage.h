//
//  TTMessage.h
//  TextOCR
//
//  Created by 王明凡 on 13-1-22.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

@interface TTMessage : UIView
{
    UILabel *content;
}
- (id)initWithFrame:(CGRect)frame text:(NSString *) text;

@end
