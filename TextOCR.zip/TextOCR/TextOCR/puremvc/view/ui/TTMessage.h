//
//  TTMessage.h
//  TextOCR
//
//  Created by MingFanWang on 13-1-22.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

@interface TTMessage : UIView
{
    UILabel *content;
}
- (id)initWithFrame:(CGRect)frame text:(NSString *) text;

@end
