//
//  TTMessage.m
//  TextOCR
//
//  Created by MingFanWang on 13-1-22.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "TTMessage.h"

@implementation TTMessage

- (id)initWithFrame:(CGRect)frame text:(NSString *) text
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor=[UIColor blackColor];
        self.alpha=0.6;
        content=[[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
        content.backgroundColor=[UIColor clearColor];
        content.textColor=[UIColor whiteColor];
        content.textAlignment=UITextAlignmentCenter;
        content.font=[UIFont boldSystemFontOfSize:20.0];
        content.text=text;
        [self addSubview:content];
    }
    return self;
}

-(void) dealloc
{
    [content release],content=nil;
    [super dealloc];
}

@end
