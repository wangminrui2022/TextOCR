//
//  TTPictureLibrary.h
//  TextOCR
//
//  Created by user on 12-12-18.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

@interface TTPictureLibrary : UIView
{
    UIImageView *backgroundImage;
    UILabel *title;
}
@property (nonatomic,retain) UIButton *back;
@property (nonatomic,retain) UIButton *deleted;
@property (nonatomic,retain) UITableView *table;

@end
