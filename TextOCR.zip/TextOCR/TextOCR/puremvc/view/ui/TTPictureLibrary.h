//
//  TTPictureLibrary.h
//  TextOCR
//
//  Created by 王明凡 on 12-12-18.
//  Copyright (c) 2012年 王明凡. All rights reserved.
//

@interface TTPictureLibrary : UIView
{
    UIImageView *backgroundImage;
    UILabel *title;
}
@property (nonatomic,retain) UIButton *back;
@property (nonatomic,retain) UIButton *deleted;
@property (nonatomic,retain) UITableView *table;

@end
