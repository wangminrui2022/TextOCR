//
//  TTPictureLibrary.m
//  TextOCR
//
//  Created by user on 12-12-18.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "TTPictureLibrary.h"
#import "TTUtil.h"
#import "TTImage.h"

@implementation TTPictureLibrary

@synthesize table=_table;
@synthesize back=_back;
@synthesize deleted=_deleted;

#pragma mark
#pragma mark 公共方法
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        //背景图片
        UIImage *bImage=[TTImage imageNamed:@"TopBar.png"];
        backgroundImage=[[UIImageView alloc] initWithImage:bImage];
        [self addSubview:backgroundImage];
        //标题
        title=[[UILabel alloc] initWithFrame:CGRectMake((backgroundImage.frame.size.width-200.0)/2,
                                                        (backgroundImage.frame.size.height-35.0)/2,
                                                        200.0, 35.0)];
        title.backgroundColor=[UIColor clearColor];
        title.textColor=[UIColor whiteColor];
        title.font=[UIFont boldSystemFontOfSize:20.0];
        title.textAlignment=UITextAlignmentCenter;
        title.text=NSLocalizedString(@"16", nil);
        [self addSubview:title];
        //本地图片列表
        self.table=[[UITableView alloc] init];
        self.table.frame=CGRectMake(0,
                                    backgroundImage.frame.size.height,
                                    self.frame.size.width,
                                    self.frame.size.height-backgroundImage.frame.size.height);
        [self addSubview:self.table];
        //返回按钮
        UIImage *backImage=[TTImage imageNamed:@"back.png"];
        self.back=[[UIButton alloc] initWithFrame:CGRectMake(10.0,
                                                             (backgroundImage.frame.size.height-backImage.size.height)/2,
                                                             backImage.size.width,
                                                             backImage.size.height)];
        [self.back.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [self.back setTitle:NSLocalizedString(@"7", nil) forState:UIControlStateNormal];
        [self.back setBackgroundImage:backImage forState:UIControlStateNormal];
        [self addSubview:self.back];
        //删除按钮
        UIImage *deletedImage=[TTImage imageNamed:@"button.png"];
        self.deleted=[[UIButton alloc] initWithFrame:CGRectMake(backgroundImage.frame.size.width-deletedImage.size.width-10,
                                                                (backgroundImage.frame.size.height-deletedImage.size.height)/2,
                                                                deletedImage.size.width,
                                                                deletedImage.size.height)];
        [self.deleted.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [self.deleted setTitle:NSLocalizedString(@"28", nil) forState:UIControlStateNormal];
        [self.deleted setBackgroundImage:deletedImage forState:UIControlStateNormal];
        [self addSubview:self.deleted];
    }
    return self;
}

-(void) dealloc
{
    [backgroundImage release],backgroundImage=nil;
    [title release],title=nil;
    [self.table release],self.table=nil;
    [_table release],_table=nil;
    [self.back release],self.back=nil;
    [_back release],_back=nil;
    [self.deleted release],self.deleted=nil;
    [_deleted release],_deleted=nil;
    [super dealloc];
}

@end
