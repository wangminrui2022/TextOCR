//
//  TTScaleBox.h
//  TextOCR
//
//  Created by user on 12-12-16.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "WMFScaleBox.h"

@interface TTScaleBox : WMFScaleBox

@end
