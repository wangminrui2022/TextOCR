//
//  TTScaleBox.m
//  TextOCR
//
//  Created by user on 12-12-16.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "TTScaleBox.h"

@implementation TTScaleBox

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

@end
