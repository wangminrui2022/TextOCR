//
//  TTScrollView.h
//  TextOCR
//
//  Created by MingFanWang on 13-1-27.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

@interface TTScrollView : UIScrollView
<UIScrollViewDelegate>
{
    UIImageView *scaleImage;
}
//
-(id)initWithFrame:(CGRect)frame image:(UIImage*) image;
//设置最大和最小缩放比例
- (void)setMaxMinZoomScalesForCurrentBounds;
//
-(CGRect) getScaleImageFrame;
//
-(UIImage *) getScaleImage;
//
-(void) setScaleImage:(UIImage*) image;

@end
