//
//  TTScrollView.m
//  TextOCR
//
//  Created by MingFanWang on 13-1-27.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "TTScrollView.h"

@implementation TTScrollView

#pragma mark
#pragma mark 公共方法
-(id)initWithFrame:(CGRect)frame image:(UIImage*) image
{
    self = [super initWithFrame:frame];
    if (self) {
        self.showsVerticalScrollIndicator = NO;
        self.showsHorizontalScrollIndicator = NO;
        self.bouncesZoom = YES;
        self.decelerationRate = UIScrollViewDecelerationRateFast;
        self.delegate = self;
        self.pagingEnabled = NO;
        self.backgroundColor=[UIColor blackColor];
        [self setScaleImage:image];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.showsVerticalScrollIndicator = NO;
        self.showsHorizontalScrollIndicator = NO;
        self.bouncesZoom = YES;
        self.decelerationRate = UIScrollViewDecelerationRateFast;
        self.delegate = self;
        self.pagingEnabled = NO;
        self.backgroundColor=[UIColor blackColor];
    }
    return self;
}

-(void) dealloc
{
    [scaleImage release],scaleImage=nil;
    [super dealloc];
}

//设置最大和最小缩放比例
- (void)setMaxMinZoomScalesForCurrentBounds
{
    CGSize boundsSize = self.bounds.size;
    CGSize imageSize = scaleImage.bounds.size;
    //计算最小/最大zoomscale.
    CGFloat xScale = boundsSize.width / imageSize.width; 
    CGFloat yScale = boundsSize.height / imageSize.height;
    CGFloat minScale = MIN(xScale, yScale);
    //我们在高分辨率屏幕上的像素密度的两倍，所以我们会看到每一个像素,如果我们限制最大变焦倍数为2.5.
    CGFloat maxScale = 5.0 / [[UIScreen mainScreen] scale];
    //不要让minScale的超过maxScale.
    if (minScale > maxScale) {
        minScale = maxScale;
    }
    self.minimumZoomScale = minScale;
    self.maximumZoomScale = maxScale;
    //设置当前显示为最小缩放效果
    self.zoomScale = self.minimumZoomScale;
}

-(CGRect) getScaleImageFrame
{
    return scaleImage.frame;
}

-(UIImage *) getScaleImage
{
    return scaleImage.image;
}

-(void) setScaleImage:(UIImage*) image
{
    if(scaleImage){
        [scaleImage removeFromSuperview];
        [scaleImage release],scaleImage=nil;
    }
    //交互图片
    scaleImage=[[UIImageView alloc] initWithImage:image];
    [self addSubview:scaleImage];
    //设置可以滚动的最大区域
    self.contentSize=scaleImage.frame.size;
    //设置最大和最小缩放比例
    [self setMaxMinZoomScalesForCurrentBounds];
}

#pragma mark
#pragma mark UIScrollView委托方法

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return scaleImage;
}

- (void)scrollViewDidZoom:(UIScrollView *)scrollView
{
    //图片居中显示
    CGFloat offsetX = (scrollView.bounds.size.width > scrollView.contentSize.width)?
    (scrollView.bounds.size.width - scrollView.contentSize.width) * 0.5 : 0.0;
    CGFloat offsetY = (scrollView.bounds.size.height > scrollView.contentSize.height)?
    (scrollView.bounds.size.height - scrollView.contentSize.height) * 0.5 : 0.0;
    UIImageView *imageView = [scrollView.subviews lastObject];
    imageView.center = CGPointMake(scrollView.contentSize.width * 0.5 + offsetX,
                                   scrollView.contentSize.height * 0.5 + offsetY);
} 

@end
