//
//  TTSlider.h
//  TextOCR
//
//  Created by 王明凡 on 13-8-28.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

#import "WMFView.h"

#define TTSLIDER_TOUCHUPINSIDE @"TTSlider_TouchUpInside"

@interface TTSlider : UIView
{
    UITextView *title;
}
@property (nonatomic,retain) UISlider *slider;

-(CGFloat) getSliderValue;

@end
