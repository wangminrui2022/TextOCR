//
//  TTSlider.h
//  TextOCR
//
//  Created by MingFanWang on 13-8-28.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "WMFView.h"

#define TTSLIDER_TOUCHUPINSIDE @"TTSlider_TouchUpInside"

@interface TTSlider : UIView
{
    UITextView *title;
}
@property (nonatomic,retain) UISlider *slider;

-(CGFloat) getSliderValue;

@end
