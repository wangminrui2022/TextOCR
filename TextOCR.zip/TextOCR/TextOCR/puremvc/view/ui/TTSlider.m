//
//  TTSlider.m
//  TextOCR
//
//  Created by 王明凡 on 13-8-28.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "TTSlider.h"
#import "TTImage.h"

@implementation TTSlider

@synthesize slider=_slider;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.slider=[[UISlider alloc] initWithFrame:CGRectMake(0, 15.0,self.frame.size.width,self.frame.size.height)];
        [self.slider setMinimumTrackTintColor:[TTUtil RGBA:4.0 green:174.0 blue:218.0 alpha:1.0]];
        [self.slider setThumbTintColor:[TTUtil RGBA:4.0 green:174.0 blue:218.0 alpha:1.0]];
        [self.slider setMinimumValue:0.0];
        [self.slider setMaximumValue:50.0];
        [self.slider setValue:10.0];
        [self.slider setContinuous:YES];
        [self.slider addTarget:self
                        action:@selector(sliderValueChanged:)
              forControlEvents:UIControlEventValueChanged];
        [self addSubview:self.slider];
        [self.slider addTarget:self
                        action:@selector(sliderTouchUpInside:)
              forControlEvents:UIControlEventTouchUpInside];
        
        title=[[UITextView alloc] initWithFrame:CGRectMake((self.frame.size.width-45.0)/2, 0, 45.0,25.0)];
        [title setBackgroundColor:[UIColor clearColor]];
        [title setTextColor:[TTUtil RGBA:4.0 green:174.0 blue:218.0 alpha:1.0]];
        [title setFont:[UIFont fontWithName:@"Helvetica-Bold" size:14.0]];
        [title setTextAlignment:NSTextAlignmentCenter];
        [self setTitle];
        [self addSubview:title];
    }
    return self;
}

-(void) dealloc
{
    [self.slider release],self.slider=nil;
    [_slider release],_slider=nil;
    [title release],title=nil;
    [super dealloc];
}

-(void)sliderValueChanged:(id)sender
{
    [self setTitle];
}

-(void)sliderTouchUpInside:(id)sender
{
    [[NSNotificationCenter defaultCenter] postNotificationName:TTSLIDER_TOUCHUPINSIDE object:sender];
}

-(CGFloat) getSliderValue
{
    CGFloat value=self.slider.value/10.0;
    NSString *text=[[NSString alloc] initWithFormat:@"%.1f",value];//精确到小数点后一位
    value=text.floatValue;
    if(value==0){
        value=0.1;
    }
    [text release],text=nil;
    return value;
}

-(void) setTitle
{
    NSString *text=[[NSString alloc] initWithFormat:@"%.1f",[self getSliderValue]];
    if(text.floatValue==10.0){
        [title setText:@"10.0"];
    }else{
        [title setText:text];
    }
    [text release],text=nil;
}

@end
