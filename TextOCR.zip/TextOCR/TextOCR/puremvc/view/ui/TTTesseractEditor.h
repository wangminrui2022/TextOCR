//
//  TTTesseractEditor.h
//  TextOCR
//
//  Created by 王明凡 on 12-12-19.
//  Copyright (c) 2012年 王明凡. All rights reserved.
//
#import "TTScrollView.h"

@interface TTTesseractEditor : UIView
{
    UIImageView *topBar;
    UIImageView *bottomBar;
    TTScrollView *tesseractImage;
    UILabel *title;
}
@property (nonatomic,retain) UIButton *back;
@property (nonatomic,retain) UIButton *OCR;
@property (nonatomic,retain) UIButton *language;

-(id)initWithFrame:(CGRect)frame image:(UIImage*) image;
-(UIImage *) getImage;

@end
