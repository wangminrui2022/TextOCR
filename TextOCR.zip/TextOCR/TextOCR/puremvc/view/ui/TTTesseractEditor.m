//
//  TTTesseractEditor.m
//  TextOCR
//
//  Created by user on 12-12-19.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "TTTesseractEditor.h"
#import "TTImage.h"

@implementation TTTesseractEditor

@synthesize back=_back;
@synthesize OCR=_OCR;
@synthesize language=_language;

#pragma mark
#pragma mark 公共方法
-(id)initWithFrame:(CGRect)frame image:(UIImage*) image
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor=[UIColor blackColor];
        //上工具条
        UIImage *tImage=[TTImage imageNamed:@"TopBar.png"];
        topBar=[[UIImageView alloc] initWithImage:tImage];
        [self addSubview:topBar];
        //标题
        title=[[UILabel alloc] initWithFrame:CGRectMake((topBar.frame.size.width-200.0)/2,
                                                        (topBar.frame.size.height-35.0)/2,
                                                        200.0, 35.0)];
        title.backgroundColor=[UIColor clearColor];
        title.textColor=[UIColor whiteColor];
        title.font=[UIFont boldSystemFontOfSize:20.0];
        title.textAlignment=UITextAlignmentCenter;
        title.text=NSLocalizedString(@"25", nil);
        [self addSubview:title];
        //返回按钮
        UIImage *backImage=[TTImage imageNamed:@"back.png"];
        self.back=[[UIButton alloc] initWithFrame:CGRectMake(10.0,
                                                             (topBar.frame.size.height-backImage.size.height)/2,
                                                             backImage.size.width,
                                                             backImage.size.height)];
        [self.back.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [self.back setTitle:NSLocalizedString(@"7", nil) forState:UIControlStateNormal];
        [self.back setBackgroundImage:backImage forState:UIControlStateNormal];
        [self addSubview:self.back];
        //下工具条
        UIImage *bImage=[TTImage imageNamed:@"BottomBar.png"];
        bottomBar=[[UIImageView alloc] initWithImage:bImage];
        [self addSubview:bottomBar];
        [bottomBar setFrame:CGRectMake(0,
                                       self.frame.size.height-bImage.size.height,
                                       bImage.size.width,
                                       bImage.size.height)];
        //识别按钮
        UIImage *tesImage=[TTImage imageNamed:@"button.png"];
        self.OCR=[[UIButton alloc] initWithFrame:CGRectMake(10.0,
                                                            bottomBar.frame.origin.y+(bottomBar.frame.size.height-tesImage.size.height)/2,
                                                            tesImage.size.width,
                                                            tesImage.size.height)];
        [self.OCR.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [self.OCR setTitle:NSLocalizedString(@"10", nil) forState:UIControlStateNormal];
        [self.OCR setBackgroundImage:tesImage forState:UIControlStateNormal];
        [self addSubview:self.OCR];
        //语言按钮
        UIImage *languageImage=[TTImage imageNamed:@"button.png"];
        self.language=[[UIButton alloc] initWithFrame:CGRectMake(bottomBar.frame.size.width-languageImage.size.width-10,
                                                                 self.OCR.frame.origin.y,
                                                                 languageImage.size.width,
                                                                 languageImage.size.height)];
        [self.language.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [self.language setTitle:NSLocalizedString(@"11", nil) forState:UIControlStateNormal];
        [self.language setBackgroundImage:languageImage forState:UIControlStateNormal];
        [self addSubview:self.language];
        //中间显示图片
        tesseractImage=[[TTScrollView alloc] initWithFrame:CGRectZero image:image];
        CGSize newSize=CGSizeMake(self.frame.size.width,
                                  self.frame.size.height-topBar.frame.size.height-bottomBar.frame.size.height);
        tesseractImage.frame=CGRectMake(0,topBar.frame.size.height,newSize.width,newSize.height);
        [tesseractImage setMaxMinZoomScalesForCurrentBounds];
        [self addSubview:tesseractImage];
    }
    return self;
}

-(void) dealloc
{
    [topBar release],topBar=nil;
    [bottomBar release],bottomBar=nil;
    [tesseractImage release],tesseractImage=nil;
    [title release],title=nil;
    [self.back release],self.back=nil;
    [_back release],_back=nil;
    [self.OCR release],self.OCR=nil;
    [_OCR release],_OCR=nil;
    [self.language release],self.language=nil;
    [_language release],_language=nil;
    
    [super dealloc];
}

-(UIImage *) getImage
{
    return [tesseractImage getScaleImage];
}
@end
