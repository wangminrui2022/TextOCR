//
//  TTTextView.h
//  TextOCR
//
//  Created by 王明凡 on 13-1-24.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//
#import "TTScrollView.h"

@interface TTTextView : UIView
{
    UIImageView *topBar;
    UILabel *title;
    UITextView *multiText;
    TTScrollView *scrollView;
}
@property (nonatomic,retain) UIButton *back;
@property (nonatomic,retain) UIButton *image;

-(void) setMultiTextText:(NSString *) text;
-(void) setMultiTextDelegate:(id<UITextViewDelegate>) delegate;
-(void) setScaleImage:(UIImage *) image;
-(void) animationImage;

@end
