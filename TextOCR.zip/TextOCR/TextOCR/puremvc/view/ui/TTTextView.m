//
//  TTTextView.m
//  TextOCR
//
//  Created by MingFanWang on 13-1-24.
//  Copyright (c) 2013年 MingFanWang. All rights reserved.
//

#import "TTTextView.h"
#import "TTImage.h"

@implementation TTTextView

@synthesize back=_back;
@synthesize image=_image;

#pragma mark
#pragma mark 公共方法
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        //上工具条
        UIImage *tImage=[TTImage imageNamed:@"TopBar.png"];
        topBar=[[UIImageView alloc] initWithImage:tImage];
        [self addSubview:topBar];
        //标题
        title=[[UILabel alloc] initWithFrame:CGRectMake((topBar.frame.size.width-200.0)/2,
                                                        (topBar.frame.size.height-35.0)/2,
                                                        200.0, 35.0)];
        title.backgroundColor=[UIColor clearColor];
        title.textColor=[UIColor whiteColor];
        title.font=[UIFont boldSystemFontOfSize:20.0];
        title.textAlignment=UITextAlignmentCenter;
        title.text=NSLocalizedString(@"14", nil);
        [self addSubview:title];
        //返回按钮
        UIImage *backImage=[TTImage imageNamed:@"back.png"];
        self.back=[[UIButton alloc] initWithFrame:CGRectMake(10.0,
                                                             (topBar.frame.size.height-backImage.size.height)/2,
                                                             backImage.size.width,
                                                             backImage.size.height)];
        [self.back.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [self.back setTitle:NSLocalizedString(@"7", nil) forState:UIControlStateNormal];
        [self.back setBackgroundImage:backImage forState:UIControlStateNormal];
        [self addSubview:self.back];
        //识别图片按钮
        UIImage *imageImage=[TTImage imageNamed:@"button.png"];
        self.image=[[UIButton alloc] initWithFrame:CGRectMake(topBar.frame.size.width-imageImage.size.width-10,
                                                             (topBar.frame.size.height-imageImage.size.height)/2,
                                                             imageImage.size.width,
                                                             imageImage.size.height)];
        [self.image.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [self.image setTitle:NSLocalizedString(@"5", nil) forState:UIControlStateNormal];
        [self.image setBackgroundImage:imageImage forState:UIControlStateNormal];
        [self addSubview:self.image];
        //多行文本
        multiText=[[UITextView alloc] initWithFrame:CGRectMake(0,
                                                               topBar.frame.size.height,
                                                               self.frame.size.width,
                                                               self.frame.size.height-topBar.frame.size.height)];
        multiText.textColor = [UIColor blackColor];//设置textview里面的字体颜色
        multiText.font = [UIFont fontWithName:@"Helvetica-Bold" size:20.0];//设置字体名字和字体大小
        multiText.returnKeyType = UIReturnKeyDone;//返回键的类型
        multiText.keyboardType = UIKeyboardTypeDefault;//键盘类型
        multiText.scrollEnabled = YES;//是否可以拖动
        multiText.autoresizingMask = UIViewAutoresizingFlexibleHeight;//自适应高度
        [self addSubview:multiText];
        //图片
        scrollView=[[TTScrollView alloc] initWithFrame:CGRectMake(0,
                                                                  ScreenHeight,
                                                                  self.frame.size.width,
                                                                  (self.frame.size.height-topBar.frame.size.height)/2)];
        [self addSubview:scrollView];
    }
    return self;
}

-(void) dealloc
{
    [topBar release],topBar=nil;
    [title release],title=nil;
    [multiText release],multiText=nil;
    [scrollView release],scrollView=nil;
    [self.back release],self.back=nil;
    [_back release],_back=nil;
    [self.image release],self.image=nil;
    [_image release];_image=nil;
    [super dealloc];
}

-(void) setMultiTextText:(NSString *) text
{
    multiText.text=text;
}

-(void) setMultiTextDelegate:(id<UITextViewDelegate>) delegate
{
    multiText.delegate=delegate;
}

-(void) setScaleImage:(UIImage *) image
{
     [scrollView setScaleImage:image];
}

-(void) animationImage
{
    multiText.contentOffset=CGPointMake(0, 0);
    if(scrollView.frame.origin.y!=ScreenHeight){
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5f];
        scrollView.frame=CGRectMake(0, ScreenHeight, scrollView.frame.size.width, scrollView.frame.size.height);
        multiText.frame=CGRectMake(0, multiText.frame.origin.y, multiText.frame.size.width, self.frame.size.height-44.0);
        [UIView commitAnimations];
    }else{
        CGFloat height=(self.frame.size.height-44.0)/2;
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5f];
        multiText.frame=CGRectMake(0, multiText.frame.origin.y, multiText.frame.size.width, height);
        scrollView.frame=CGRectMake(0, multiText.frame.origin.y+height, scrollView.frame.size.width, height);
        [UIView commitAnimations];
    }
}

@end
