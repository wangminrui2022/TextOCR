//
//  TTFilter.h
//  TextOCR
//
//  Created by 王明凡 on 13-9-2.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

#define SAFECOLOR(color) MIN(255,MAX(0,color))

//结构体定义
typedef struct _singleRGBA
{
    unsigned char red;
    unsigned char green;
    unsigned char blue;
    unsigned char alpha;
} RGBA;

//函数指针定义
typedef void (*FilterFunction)(UInt8 *pixelBuf, UInt32 offset,void *context);

@interface TTFilter : NSObject
{
    
}

-(UIImage *) filterOpacityWithImage:(CGImageRef) image context:(void*)context;
-(UIImage *) filterBrightnessWithImage:(CGImageRef) image context:(void*)context;
-(UIImage *) filterSaturationWithImage:(CGImageRef) image context:(void*)context;
-(UIImage *) filterContrastWithImage:(CGImageRef) image context:(void*)context;
-(UIImage *) filterPosterizeWithImage:(CGImageRef) image context:(void*)context;
-(UIImage *) filterDesaturateWithImage:(CGImageRef) image context:(void*)context;
-(UIImage *) filterInvertWithImage:(CGImageRef) image context:(void*)context;
@end
