//
//  TTFilter.m
//  TextOCR
//
//  Created by 王明凡 on 13-9-2.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

#import "TTFilter.h"

@implementation TTFilter


#pragma mark
#pragma mark 私有方法
-(UIImage*)applyFilter:(FilterFunction)filter inImage:(CGImageRef) inImage context:(void*)context
{
    CFDataRef m_DataRef = CGDataProviderCopyData(CGImageGetDataProvider(inImage));
    UInt8 *m_PixelBuf = (UInt8 *)CFDataGetBytePtr(m_DataRef);
    int length = CFDataGetLength(m_DataRef);
    for (int i=0; i<length; i+=4) {
        filter(m_PixelBuf, i, context);
    }
    CGContextRef ctx = CGBitmapContextCreate(m_PixelBuf,
                                             CGImageGetWidth(inImage),
                                             CGImageGetHeight(inImage),
                                             CGImageGetBitsPerComponent(inImage),
                                             CGImageGetBytesPerRow(inImage),
                                             CGImageGetColorSpace(inImage),
                                             CGImageGetBitmapInfo(inImage));
    CGImageRef imageRef = CGBitmapContextCreateImage(ctx);
    CGContextRelease(ctx);
    UIImage *finalImage = [UIImage imageWithCGImage:imageRef];
    CGImageRelease(imageRef);
    CFRelease(m_DataRef);
    return finalImage;
}

#pragma mark
#pragma mark 公共方法
//透明度 0.5
-(UIImage *) filterOpacityWithImage:(CGImageRef) image context:(void*)context
{
    return [self applyFilter:filterOpacity inImage:image context:context];
}
//亮度 1.2
-(UIImage *) filterBrightnessWithImage:(CGImageRef) image context:(void*)context
{
    return [self applyFilter:filterBrightness inImage:image context:context];
}
//饱和度 2.0 [0, 2]
-(UIImage *) filterSaturationWithImage:(CGImageRef) image context:(void*)context
{
    return [self applyFilter:filterSaturation inImage:image context:context];
}
//对比度 [0, 10]
-(UIImage *) filterContrastWithImage:(CGImageRef) image context:(void*)context
{
    return [self applyFilter:filterContrast inImage:image context:context];
}
//着色 maxRGBA:(RGBA){190, 190, 230} minRGBA:(RGBA){50, 35, 10}
-(UIImage *) filterTintWithImage:(CGImageRef) image maxRGBA:(RGBA) maxRGBA minRGBA:(RGBA) minRGBA
{
    RGBA rgbaArray[]={maxRGBA,minRGBA};
    return [self applyFilter:filterTint inImage:image context:rgbaArray];
}
-(UIImage *) filterPosterizeWithImage:(CGImageRef) image context:(void*)context
{
    return [self applyFilter:filterPosterize inImage:image context:context];
}
-(UIImage *) filterDesaturateWithImage:(CGImageRef) image context:(void*)context
{
    return [self applyFilter:filterDesaturate inImage:image context:context];
}
-(UIImage *) filterInvertWithImage:(CGImageRef) image context:(void*)context
{
    return [self applyFilter:filterInvert inImage:image context:context];
}

#pragma mark
#pragma mark C方法
//透明度
void filterOpacity(UInt8 *pixelBuf, UInt32 offset, void *context)
{
	double val = *((double*)context);
	int a = offset+3;//获得RGBA的alpha值
	int alpha = pixelBuf[a];
	pixelBuf[a] = SAFECOLOR(alpha * val);
}

//亮度
void filterBrightness(UInt8 *pixelBuf, UInt32 offset, void *context)
{
	double t = *((double*)context);
	
	int r = offset;
	int g = offset+1;
	int b = offset+2;
	
	int red = pixelBuf[r];
	int green = pixelBuf[g];
	int blue = pixelBuf[b];

	pixelBuf[r] = SAFECOLOR(red * t);
	pixelBuf[g] = SAFECOLOR(green * t);
	pixelBuf[b] = SAFECOLOR(blue * t);
}

//饱和度
void filterSaturation(UInt8 *pixelBuf, UInt32 offset, void *context)
{
	double t = *((double*)context); // t (- [0, 2]
	
	int r = offset;
	int g = offset+1;
	int b = offset+2;
	
	int red = pixelBuf[r];
	int green = pixelBuf[g];
	int blue = pixelBuf[b];
    
    red = red * (0.3086 * (1-t) + t) + green * (0.6094 * (1-t)) + blue * (0.0820 * (1-t));
    green = red * (0.3086 * (1-t)) + green * ((0.6094 * (1-t)) + t) + blue * (0.0820 * (1-t));
    blue = red * (0.3086 * (1-t)) + green * (0.6094 * (1-t)) + blue * ((0.0820 * (1-t)) + t);
	
	pixelBuf[r] = SAFECOLOR(red);
	pixelBuf[g] = SAFECOLOR(green);
	pixelBuf[b] = SAFECOLOR(blue);
}

//对比度
void filterContrast(UInt8 *pixelBuf, UInt32 offset, void *context)
{
    double t = *((double*)context); // t (- [0, 10]
	
	int r = offset;
	int g = offset+1;
	int b = offset+2;
	
	int red = pixelBuf[r];
	int green = pixelBuf[g];
	int blue = pixelBuf[b];
    
    red = red * t + 128 * (1-t);
    green = green * t + 128 * (1-t);
    blue = blue * t + 128 * (1-t);
	
	pixelBuf[r] = SAFECOLOR(red);
	pixelBuf[g] = SAFECOLOR(green);
	pixelBuf[b] = SAFECOLOR(blue);
}

//着色
void filterTint(UInt8 *pixelBuf, UInt32 offset, void *context)
{
    RGBA *rgbaArray = (RGBA*)context;
    RGBA maxRGBA = rgbaArray[0];
    RGBA minRGBA = rgbaArray[1];
    
	int r = offset;
	int g = offset+1;
	int b = offset+2;
	
	int red = pixelBuf[r];
	int green = pixelBuf[g];
	int blue = pixelBuf[b];
	
	pixelBuf[r] = SAFECOLOR((red - minRGBA.red) * (255.0 / (maxRGBA.red - minRGBA.red)));
	pixelBuf[g] = SAFECOLOR((green - minRGBA.green) * (255.0 / (maxRGBA.green - minRGBA.green)));
	pixelBuf[b] = SAFECOLOR((blue - minRGBA.blue) * (255.0 / (maxRGBA.blue - minRGBA.blue)));
}

void filterPosterize(UInt8 *pixelBuf, UInt32 offset, void *context)
{
    double levels = *((double*)context);
	if (levels == 0) levels = 1; // avoid divide by zero
	int step = 255 / levels;
	
	int r = offset;
	int g = offset+1;
	int b = offset+2;
	
	int red = pixelBuf[r];
	int green = pixelBuf[g];
	int blue = pixelBuf[b];
	
	pixelBuf[r] = SAFECOLOR((red / step) * step);
	pixelBuf[g] = SAFECOLOR((green / step) * step);
	pixelBuf[b] = SAFECOLOR((blue / step) * step);
}

void filterDesaturate(UInt8 *pixelBuf, UInt32 offset, void *context)
{
	int r = offset;
	int g = offset+1;
	int b = offset+2;
	
	int red = pixelBuf[r];
	int green = pixelBuf[g];
	int blue = pixelBuf[b];
    
    red = red * 0.3086 + green * 0.6094 + blue * 0.0820;
    green = red * 0.3086 + green * 0.6094 + blue * 0.0820;
    blue = red * 0.3086 + green * 0.6094 + blue * 0.0820;
	
	pixelBuf[r] = SAFECOLOR(red);
	pixelBuf[g] = SAFECOLOR(green);
	pixelBuf[b] = SAFECOLOR(blue);
}

void filterInvert(UInt8 *pixelBuf, UInt32 offset, void *context)
{
	int r = offset;
	int g = offset+1;
	int b = offset+2;
	
	int red = pixelBuf[r];
	int green = pixelBuf[g];
	int blue = pixelBuf[b];
	
	pixelBuf[r] = SAFECOLOR(255-red);
	pixelBuf[g] = SAFECOLOR(255-green);
	pixelBuf[b] = SAFECOLOR(255-blue);
}


@end
