//
//  TTSize.h
//  TextOCR
//
//  Created by 王明凡 on 13-9-2.
//  Copyright (c) 2013年 王明凡. All rights reserved.
//

#ifndef TextOCR_TTSize_h
#define TextOCR_TTSize_h



#endif

//获取屏幕宽高
#define ScreenHeight [[UIScreen mainScreen] bounds].size.height
#define ScreenWidth [[UIScreen mainScreen] bounds].size.width
//状态条高度
#define StateBarHeight 20.0
//程序宽高
#define MainHeight (ScreenHeight - StateBarHeight)
#define MainWidth ScreenWidth