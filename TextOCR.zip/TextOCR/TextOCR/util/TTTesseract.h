//
//  TTTesseract.h
//  TextOCR
//
//  Created by MingFanWang on 12-12-16.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

namespace tesseract {
    class TessBaseAPI;
};

typedef enum { 
    English, 
    Chinese 
} TTLanguageType;

@interface TTTesseract : NSObject
{
    tesseract::TessBaseAPI *tesseract;
    uint32_t *pixels;
}
//根据识别语言类型初始化
-(id) initWithLanguageType:(TTLanguageType) type;
//传入一个图片进行识别
-(NSString *) ocrProcessingWithImage:(UIImage *)image;

@end
