//
//  TTTesseract.m
//  TextOCR
//
//  Created by MingFanWang on 12-12-16.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "TTTesseract.h"
#import "TTUtil.h"
#include "baseapi.h"
#include "environ.h"
#import "pix.h"

@implementation TTTesseract
 
#pragma mark
#pragma mark 私有方法
//获得识别语言类型
-(const char *) getLanguage:(TTLanguageType) type
{
    const char * language = NULL;
    switch (type) 
    {
        case English:
            language="eng";
            break;
        case Chinese:
            language="chi_sim";
            break;
        default:
            break;
    }
    return language;
}
//设置要识别的图片
- (void)setTesseractImage:(UIImage *)image
{
    int width = [image size].width;
    int height = [image size].height;
	if (width <= 0 || height <= 0)
    {
		return;
    }
    //将像素绘到这个数组
    pixels = (uint32_t *) malloc(width * height * sizeof(uint32_t));
    if (NULL == pixels) 
    { 
        exit (1); 
    } 
    //清除像素，保持透明度
    memset(pixels, 0, width * height * sizeof(uint32_t));
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    //创建一个上下文RGBA像素
    CGContextRef context = CGBitmapContextCreate(pixels, width, height, 8, width * sizeof(uint32_t), colorSpace, 
                                                 kCGBitmapByteOrder32Little | kCGImageAlphaPremultipliedLast);
    //绘制位图的上下文，这将填补在像素数组
    CGContextDrawImage(context, CGRectMake(0, 0, width, height), [image CGImage]);
    CGContextRelease(context);
    CGColorSpaceRelease(colorSpace);
    tesseract->SetImage((const unsigned char *) pixels, width, height, sizeof(uint32_t), width * sizeof(uint32_t));
}

#pragma mark
#pragma mark 公共方法
-(id) initWithLanguageType:(TTLanguageType) type
{
    self = [super init];
    if (self) 
    {
        /*
         tesseract-ocr-3.02.02版本使用tesseract-ocr-3.02.chi_sim中文语言文件进行识别报以下错误，而且识别率很低。
            Too many unichars in ambiguity on line -803993832
            Too many unichars in ambiguity on line -803993832
         解决办法：使用tesseract-ocr-3.00.chi_sim的中文语言文件。
         */
        //设置起来的tessdata的路径，这是包含在应用程序包，但是在第一次运行复制到文件目录。
        NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentPath = ([documentPaths count] > 0) ? [documentPaths objectAtIndex:0] : nil;
        NSString *dataPath = [documentPath stringByAppendingPathComponent:@"tessdata"];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        //如果预期的位置不存在，复制默认存储位置。
        if (![fileManager fileExistsAtPath:dataPath]) 
        {
            //得到的路径的应用程序包（tessdata的目录）
            NSString *bundlePath = [[NSBundle mainBundle] bundlePath];
            NSString *tessdataPath = [bundlePath stringByAppendingPathComponent:@"tessdata"];
            if (tessdataPath) 
            {
                [fileManager copyItemAtPath:tessdataPath toPath:dataPath error:NULL];
            }
        }
        setenv("TESSDATA_PREFIX", [[documentPath stringByAppendingString:@"/"] UTF8String], 1);
        //初始化tesseract引擎
        tesseract = new tesseract::TessBaseAPI();
        //初始化语言路径和语言类型
        const char *language=[self getLanguage:type];
        const char *path=[dataPath cStringUsingEncoding:NSUTF8StringEncoding];
        printf("%s,%s",language,path);
        tesseract->Init(path,language);
        NSLog(@"程序版本号:%s",tesseract->Version());
    }
    return self;
}

- (void)dealloc 
{
    free(pixels);
    tesseract->Clear();
    delete tesseract;
    tesseract = nil;
    [super dealloc];
}

-(NSString *) ocrProcessingWithImage:(UIImage *)image
{
    [self setTesseractImage:image];
    tesseract->Recognize(NULL);
    char* utf8Text = tesseract->GetUTF8Text();
    NSString *str=[NSString stringWithUTF8String:utf8Text];
    str=[NSString stringWithFormat:@"%@", str];
    delete []utf8Text;
    return str;
}

@end
