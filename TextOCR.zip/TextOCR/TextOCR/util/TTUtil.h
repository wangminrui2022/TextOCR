//
//  TTUtil.h
//  TextOCR
//
//  Created by 王明凡 on 12-10-7.
//  Copyright (c) 2012年 王明凡. All rights reserved.
//

@interface TTUtil : NSObject

//根据文件名获取该文件相对于当前工程的绝对路径
+(NSString *) AbsolutePathWithFileName:(NSString *) fileName;
//获取当前设备可用内存(单位MB)
+(double)availableMemory;
//获取当前任务所占用的内存(单位MB)
+(double)usedMemory;
//获得picture图片名字路径
+(NSString *) getPictureFilePath;
//获取一个被格式化的日期或时间
+(NSString *) getFormatterDatetime:(NSString *) fromatter;
//等比例缩放图片显示在容器中
+(CGRect) scaleFrameWithContainer:(CGSize) container child:(CGSize) child;
//获取屏幕分辨率
+(CGSize) mainScreen;
//获得一个ARGB颜色
+(UIColor *) RGBA:(CGFloat) read green:(CGFloat) green blue:(CGFloat) blue alpha:(CGFloat) alpha;
//在原有的图片重绘一个指定CGRect的图片
+(UIImage *) drawImageWithFrame:(CGRect) frame image:(UIImage *)image;
//复制位图
+(UIImage *) copyImage:(UIImage *)image;

@end
