//
//  TTUtil.m
//  TextOCR
//
//  Created by 王明凡 on 12-10-7.
//  Copyright (c) 2012年 MingFanWang. All rights reserved.
//

#import "TTUtil.h"
// 获取当前设备可用内存及所占内存的头文件
#import <sys/sysctl.h>
#import <mach/mach.h>

@implementation TTUtil
 
#pragma mark
#pragma mark 类方法

+(NSString *) AbsolutePathWithFileName:(NSString *) fileName
{
    NSString *resourcePath=[[NSBundle mainBundle] resourcePath];
    NSString *absolutePath=[resourcePath stringByAppendingPathComponent:fileName];
//    _string(1,absolutePath);
    return absolutePath;
}

+(double)availableMemory
{
    vm_statistics_data_t vmStats;
    mach_msg_type_number_t infoCount = HOST_VM_INFO_COUNT;
    kern_return_t kernReturn = host_statistics(mach_host_self(), 
                                               HOST_VM_INFO, 
                                               (host_info_t)&vmStats, 
                                               &infoCount);
    if (kernReturn != KERN_SUCCESS) {
        return NSNotFound;
    }
    return ((vm_page_size *vmStats.free_count) / 1024.0) / 1024.0;
}

+(double)usedMemory
{
    task_basic_info_data_t taskInfo;
    mach_msg_type_number_t infoCount = TASK_BASIC_INFO_COUNT;
    kern_return_t kernReturn = task_info(mach_task_self(), 
                                         TASK_BASIC_INFO, 
                                         (task_info_t)&taskInfo, 
                                         &infoCount);
    if (kernReturn != KERN_SUCCESS) {
        return NSNotFound;
    }
    return taskInfo.resident_size / 1024.0 / 1024.0;
}

+(NSString *) getPictureFilePath
{  
    NSString *fileName = [TTUtil getFormatterDatetime:@"yyyy-MM-dd_HH-mm-ss-SSS"];
    fileName=[fileName stringByAppendingString:@".png"];
    NSString *filePath =[[TTUtil AbsolutePathWithFileName:@"picture"] stringByAppendingPathComponent:fileName]; 
    return  filePath;  
} 

+(NSString *) getFormatterDatetime:(NSString *) fromatter
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];  
    [formatter setDateStyle:NSDateFormatterMediumStyle];  
    [formatter setTimeStyle:NSDateFormatterShortStyle];  
    [formatter setDateFormat:fromatter];  
    NSString *datetime = [formatter stringFromDate:[NSDate date]];  
    [formatter release],formatter=nil;
    return datetime;
}

+(CGRect) scaleFrameWithContainer:(CGSize) container child:(CGSize) child
{
    CGRect scale;
    CGSize size;
//    _float(2,child.width,child.height);
    if (child.width>container.width && child.width>=child.height) {
        NSInteger tw=child.width-(child.width-container.width);
        CGFloat pw=tw/child.width;//计算比例
        size=CGSizeMake(tw, pw*child.height);
    }else if (child.height>container.height && child.height>=child.width) {
        NSInteger th=child.height-(child.height-container.height);
        CGFloat ph=th/child.height;//计算比例
        size=CGSizeMake(ph*child.width,th);	
    }else {
        size=CGSizeMake(child.width, child.height);
    }
    scale=CGRectMake((container.width-size.width)/2, 
                     (container.height-size.height)/2,
                     size.width,
                     size.height);
//    _float(4,scale.origin.x,scale.origin.y,scale.size.width,scale.size.height);
    return scale;
}

+(CGSize) mainScreen
{
    CGRect rect = [[UIScreen mainScreen] bounds];
    return rect.size;
}

+(UIColor *) RGBA:(CGFloat) read green:(CGFloat) green blue:(CGFloat) blue alpha:(CGFloat) alpha;
{
    return [UIColor colorWithRed:read/255.0 green:green/255.0 blue:blue/255.0 alpha:alpha];
}

+(UIImage *) drawImageWithFrame:(CGRect) frame image:(UIImage *)image
{
    //根据size大小创建一个基于位图的图形上下文
    UIGraphicsBeginImageContext(frame.size);
    //获取当前Quartz 2D绘图环境
    CGContextRef context = UIGraphicsGetCurrentContext();
    //设置当前绘图环境到矩形框
    CGContextClipToRect(context, frame);
    //绘制
    [image drawInRect:frame];
    //获得图片
    UIImage *drawImage = UIGraphicsGetImageFromCurrentImageContext();
    //从当前堆栈中删除Quartz 2D绘图环境
    UIGraphicsEndImageContext();
    return drawImage;
}

+(UIImage *) copyImage:(UIImage *)image
{
    return [[UIImage imageWithCGImage:[image CGImage]] retain];
}
@end
